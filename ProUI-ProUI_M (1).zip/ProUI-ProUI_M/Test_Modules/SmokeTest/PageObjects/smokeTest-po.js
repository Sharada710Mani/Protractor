/**
 * Created by ravkumar on 21/1/2018.
 *  * */
var currentPage = "smokeTest";
function smokeTest() {
    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var smokeTestObjectManager = objectManager.getLocalObjectManager("SmokeTest", "smokeTest", currentPage);
    var smokeTestElementManager = smokeTestObjectManager.ElementManager;
    var ObjTestHelper = smokeTestObjectManager.TestHelper;
    var EC = protractor.ExpectedConditions;
    var self = this;
    this.waitTime = 90000;
    var promiseUtilFile = require('../../../Common_Template/PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();

    this.validateSearch = function () {
        return ObjTestHelper.isElementPresent(currentPage, "searchResult").then(function (displayed) {
            expect(displayed).to.equal(true);
            smokeTestElementManager.findElement(currentPage, "searchResult").click().catch(function(){
            console.log('catch occurred');    
            });
            console.log("Search Result Open");
            var parentFamily = smokeTestElementManager.findElement(currentPage, "parentFamily");
            promiseUtil.isElementDisplayed(parentFamily);          
        });
    };

    this.mnuHealth = function (health) {
        return ObjTestHelper.isElementPresent(currentPage, "mnuHealth").then(function (displayed) {
            expect(displayed).to.equal(true);
            var mnuHealth = smokeTestElementManager.findElement(currentPage, "mnuHealth").getText();
            ObjTestHelper.assertEqual(mnuHealth, health);
        });
    };

    this.mnuReliability = function (reliability) {
        return ObjTestHelper.isElementPresent(currentPage, "mnuReliability").then(function (displayed) {
            expect(displayed).to.equal(true);
            var mnuReliability = smokeTestElementManager.findElement(currentPage, "mnuReliability").getText();
            ObjTestHelper.assertEqual(mnuReliability, reliability);
        });
    };
   
    this.mnuIntegrity = function (integrity) {
        return ObjTestHelper.isElementPresent(currentPage, "mnuIntegrity").then(function (displayed) {
            expect(displayed).to.equal(true);
            var mnuIntegrity = smokeTestElementManager.findElement(currentPage, "mnuIntegrity").getText();
            ObjTestHelper.assertEqual(mnuIntegrity, integrity);
        });

    };
    this.mnuStrategy = function (strategy) {
        return ObjTestHelper.isElementPresent(currentPage, "mnuStrategy").then(function (displayed) {
            expect(displayed).to.equal(true);
            var mnuStrategy = smokeTestElementManager.findElement(currentPage, "mnuStrategy").getText();
            ObjTestHelper.assertEqual(mnuStrategy, strategy);
        });

    };
    this.mnuTools = function (tools) {
        return ObjTestHelper.isElementPresent(currentPage, "mnuTools").then(function (displayed) {
            expect(displayed).to.equal(true);
            var mnuTools = smokeTestElementManager.findElement(currentPage, "mnuTools").getText();
            ObjTestHelper.assertEqual(mnuTools, tools);
        });

    };
    this.mnuAdmin = function (admin) {
        return ObjTestHelper.isElementPresent(currentPage, "mnuAdmin").then(function (displayed) {
            expect(displayed).to.equal(true);
            var mnuAdmin = smokeTestElementManager.findElement(currentPage, "mnuAdmin").getText();
            ObjTestHelper.assertEqual(mnuAdmin, admin);
        });
    };
    this.closePopUp = function () {
        var deferred = protractor.promise.defer();     
        browser.sleep(3000);
         smokeTestElementManager.findElement(currentPage, "closePopUp").isDisplayed().then(function (displayed) {           
            if (displayed) 
            {
                smokeTestElementManager.findElement(currentPage, "closePopUp").click().then(function(){
                    browser.sleep(3000);
                    console.log("Close the Error Pop Up");
                    deferred.fulfill(true);
                });
            }
            else {
                console.log("No Error Pop up appears");
                deferred.fulfill(true);
            }
        },function(){deferred.fulfill(true);});
        return deferred.promise;
    };
}

module.exports = new smokeTest();