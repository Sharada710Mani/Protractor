var smokeTestStepDefinitions = function () {
    var smokeTestPage = require('../PageObjects/smokeTest-po.js');
    this.setDefaultTimeout(60*1000*60);
    this.Given(/^Test Login to Unified Application$/, function (callback) {

        browser.ignoreSynchronization = true;
        login.navigateAndLogin().then(function () {
            callback();
        });
    });  
    this.Then(/^Click on Global Search Icon and enter the family name to search$/, function (callback) {
        searchManager.globalSearchOnly("Equipment").then(function () {
            callback();
        });
    });
    this.Then(/^Validate Global Search is Working$/, function (callback) {
        smokeTestPage.validateSearch().then(function () {
            callback();
        });
    });

    this.Given(/^Health Menu display at HomePage$/, function (callback) {
        smokeTestPage.mnuHealth("Health").then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Health Menu and Asset Criticality Analysis SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis).then(function () {
            callback();
        });
    });
    this.Then(/^Check error Pop up Window not appears$/, function (callback) {
        smokeTestPage.closePopUp().then(function () {
            callback();
        });
    });
    this.Then(/^Close Current Tab$/, function (callback) {
        tabPO.closeCurrentTab(3000).then(function () {
            console.log("Close Current tab successful")
            callback();

        });
    });

    this.Then(/^Navigate to Health Menu and Calibration Management SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.health, subMenu.healthCalibrationManagement).then(function () {
            callback();
        });
    });
    this.Given(/^Reliability Menu display at HomePage$/, function (callback) {
        smokeTestPage.mnuReliability("Reliability").then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Reliability Menu and Production Loss Analysis SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.reliability, subMenu.reliabilityProductionLossAnalysis).then(function () {
            callback();
        });
    });    
    this.Then(/^Navigate to Reliability Menu and Root Cause Analysis SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.reliability, subMenu.reliabilityRootCauseAnalysis).then(function () {
            callback();
        });
    });
    // this.Then(/^Close All Open Tabs$/, function (callback) {
    //     tabPO.closeAllTabs(5000).then(function () {
    //         callback();
    //     });
    // });

   
    this.Given(/^Strategy Menu display at HomePage$/, function (callback) {
        smokeTestPage.mnuStrategy("Strategy").then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Strategy Menu and Asset Strategy Implementation SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.strategy, subMenu.strategyAssetStrategyImplementation).then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Strategy Menu and Asset Strategy Management SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.strategy, subMenu.strategyAssetStrategyManagement).then(function () {
            callback();
        });
    });

    this.Then(/^Navigate to Strategy Menu and Reliability Centered Maintenance SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.strategy, subMenu.strategyReliabilityCenteredMaintenance).then(function () {
            callback();
        });
    });
    this.Given(/^Integrity Menu display at HomePage$/, function (callback) {
        smokeTestPage.mnuIntegrity("Integrity").then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Integrity Menu and Hazards Analysis SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.integrity, subMenu.integrityHazardsAnalysis).then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Integrity Menu and Risk Based Inspection SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.integrity, subMenu.integrityRiskBasedInspection).then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Integrity Menu and Thickness Monitoring SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.integrity, subMenu.integrityThicknessMonitoring).then(function () {
            callback();
        });
    });
    this.Given(/^Tools Menu display at HomePage$/, function (callback) {
        smokeTestPage.mnuTools("Tools").then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Tools Menu and Metrics and Scorecards SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.tools, subMenu.toolsMetricsandScorecards).then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Tools Menu and Policy Designer SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.tools, subMenu.toolsPolicyDesigner).then(function () {
            callback();
        });
    });

    this.Then(/^Navigate to Tools Menu and Data Loaders SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.tools, subMenu.toolsDataLoaders).then(function () {
            callback();
        });
    });

    this.Given(/^Admin Menu display at HomePage$/, function (callback) {
        smokeTestPage.mnuAdmin("Admin").then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Admin Menu and Application Settings SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.admin, subMenu.adminApplicationSettings).then(function () {
            callback();
        });
    });

    this.Then(/^Navigate to Admin Menu and Configuration Manager SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.admin, subMenu.adminConfigurationManager).then(function () {
            callback();
        });
    });
    this.Then(/^Navigate to Admin Menu and Operations Manager SubMenu$/, function (callback) {
        navigation.navigateToScreen(menu.admin, subMenu.adminOperationsManager).then(function () {
            callback();
        });
    });

};
module.exports = smokeTestStepDefinitions;

