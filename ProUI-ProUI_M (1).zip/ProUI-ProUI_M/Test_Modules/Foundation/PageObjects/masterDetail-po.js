/**
 * Created by ravkumar on 1/5/2018.
 *  
 * */
'use strict';
var currentPage = 'masterDetail';
var masterDetailPage =function () {
    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var masterDetailObjectManager = objectManager.getLocalObjectManager("Foundation","masterDetail",currentPage);
    var masterDetailElementManager = masterDetailObjectManager.ElementManager;
    var ObjTestHelper = masterDetailObjectManager.TestHelper;
    var EC = protractor.ExpectedConditions;
    var self = this;
    this.waitTime = 60000;
    
     /**
     * This function will Validate the Master tab on AQA Master for MDF Record Manager
     */   
    this.tabMaster = function (tab) {

        ObjTestHelper.isElementPresent(currentPage, "tabMaster").then(function () {
            var master = masterDetailElementManager.findElement(currentPage, "tabMaster").getText();
            ObjTestHelper.assertEqual(master, tab);

        })
    };
    /**
     * This function will click on  Master tab 
     */
    this.navigateToMaster = function () {
        masterDetailElementManager.findElement(currentPage, "tabMaster").click();
        ObjTestHelper.isElementPresent(currentPage, "txtCharId").then(function (displayed) {
            ObjTestHelper.assertEqual(master, true);
        })
    };

    /**
     * This function will Validate the Detail tab on AQA Master for MDF Record Manager
     */ 
    this.tabDetail = function (tab) {

        ObjTestHelper.isElementPresent(currentPage, "tabDetail").then(function () {
            var detail = masterDetailElementManager.findElement(currentPage, "tabDetail").getText();
            ObjTestHelper.assertEqual(detail, tab);

        })
    };
    /**
     * This function will click on  Detail tab 
     */   
    this.navigateToDetail = function () {
        masterDetailElementManager.findElement(currentPage, "tabDetail").click();
        ObjTestHelper.isElementPresent(currentPage, "txtCharValue").then(function (displayed) {
            ObjTestHelper.assertEqual(master, true);
        })
    };
  
/**
     * This function will Enter Test Data(char, Num,Text)in master Family
     */ 
    this.EnterDetailsInMaster = function (charId, num, text) {

        ObjTestHelper.isElementPresent(currentPage, "txtCharId").then(function (displayed) {
            expect(displayed).to.equal(true);
            if (displayed) {
                var txtCharID = masterDetailElementManager.findElement(currentPage, "txtCharId");
                var txtNum = masterDetailElementManager.findElement(txtNum, "txtDescription");
                var txtText = masterDetailElementManager.findElement(txtNum, "txtText");
                txtCharID.sendKeys(charId);
                console.log("Enter char value in Char ID textbox " + charId + "");
                txtNum.sendKeys(num);
                console.log("Enter Integer in Number field" + num + "");
                txtNum.sendKeys(txtText);
                console.log("Enter Text in Text field" + text + "");
            }
        })
    };
    /**    
     * save the dataSheet: This function will save  New Record    
     * @param values : Enter the values in Datasheet.
     * @returns {*}
     */
    this.saveDatasheet = function () {
        ObjTestHelper.isElementPresent(currentPage, "txtCharId").then(function (displayed) {
            expect(displayed).to.equal(true);
            createRecordElementManager.findElement(currentPage, "iconSave").click()
            console.log("Record Manager is saved");
            ObjTestHelper.isElementPresent(currentPage, "parentFamily").then(function (displayed) {
                expect(displayed).to.equal(true);
            })
        })
    };

    this.validateDatasheet = function (charId) {
        var parentRecord = masterDetailElementManager.findElement(currentPage, "parentFamily").getText();
        ObjTestHelper.assertEqual(parentRecord, charId);
    };
    
    

}