/**
 * Created by ravkumar on 21/12/2017.
 *  * */
'use strict';
var currentPage = 'refDoc';
var refDocPage = function () {
    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var refDocObjectManager = objectManager.getLocalObjectManager("Foundation", "refDoc", currentPage);
    var refDocElementManager = refDocObjectManager.ElementManager;
    var ObjTestHelper = refDocObjectManager.TestHelper;
    var EC = protractor.ExpectedConditions;
    var self = this;
    this.waitTime = 60000;
    var promiseUtilFile = require('../../../Common_Template/PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();

    /**
   * This function will validate add new RefDoc icon on Ref Doc Page     
   */
    this.addRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "addRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate add RefDoc icon present on RefDoc Page");
        })
    };
    /**
   * This function will validate link RefDoc icon on Ref Doc Page     
   */
    this.linkRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "linkRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate link icon present on RefDoc Page");
        })
    };
    /**
     * This function will validate search RefDoc icon on Ref Doc Page     
     */
    this.iconSearchUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "iconSearch").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate search icon present on RefDoc Page");
        })
    };
    /**
    * This function will validate edit RefDoc icon on Ref Doc Page     
    */
    this.editRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "editRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate edit icon present on RefDoc Page");
        })
    };
    /**
    * This function will validate delete RefDoc icon on Ref Doc Page     
    */
    this.deleteRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "deleteRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate delete icon present on RefDoc Page");
        })
    };
    /**
     * This function will validate unlink RefDoc icon on Ref Doc Page     
     */
    this.unlinkRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "unlinkRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate unlink icon present on RefDoc Page");
        })
    };
    /**
     * This function will validate disable unlink icon on Ref Doc Page     
     */
    this.disUnlinkRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "disUnlinkRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate disable icon unlink present on RefDoc Page");
        })
    };
    this.disDeleteRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "disDeleteRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate disable icon delete present on RefDoc Page");
        })
    };
    /**
     * This function will validate disable edit icon on Ref Doc Page     
     */
    this.disEditRefDocUI = function () {
        return ObjTestHelper.isElementPresent(currentPage, "disEditRefDoc").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("validate disable icon edit present on RefDoc Page");
        })
    };
    /**
     * This function will validate disable column on Ref Doc Page     
     */
    this.validateColInRefDoc = function (id, desc, lastUpdatedBy, lastUpdatedDate) {
        return ObjTestHelper.isElementPresent(currentPage, "colID").then(function (displayed) {
            expect(displayed).to.equal(true);
            var colID = refDocElementManager.findElement(currentPage, "colID").getText();
            ObjTestHelper.assertEqual(colID, id);
            console.log("validate col ID present on RefDoc Page");
            var colDesc = refDocElementManager.findElement(currentPage, "colDes").getText();
            ObjTestHelper.assertEqual(colDesc, desc);
            console.log("validate col Description present on RefDoc Page");
            var colLastUpdatedBy = refDocElementManager.findElement(currentPage, "colLastUpdatedBy").getText();
            ObjTestHelper.assertEqual(colLastUpdatedBy, lastUpdatedBy);
            console.log("validate col col LastUpdatedBy present on RefDoc Page");
            var colLastUpdatedDate = refDocElementManager.findElement(currentPage, "colLastUpdatedDate").getText();
            ObjTestHelper.assertEqual(colLastUpdatedDate, lastUpdatedDate);
            console.log("validate col col LastUpdatedDate present on RefDoc Page");
        })

    };
    /**
    * create RefDoc: This function will create RefDoc  
    *  * @param Ref Doc Id  : Provide the value in Ref Doc Id and Description
    * @returns {*} 
    */
    this.createRefDoc = function (refDoc, description, isSave) {
        refDocElementManager.findElement(currentPage, "addRefDoc").click();
        return ObjTestHelper.isElementPresent(currentPage, "txtID").then(function (displayed) {
            expect(displayed).to.equal(true);
            if (displayed) {
                var textID = refDocElementManager.findElement(currentPage, "txtID");
                var textDescription = refDocElementManager.findElement(currentPage, "txtDescription");
                textID.sendKeys(refDoc);
                console.log("Enter ref doc value in ID textbox " + refDoc + "");
                textDescription.sendKeys(description);
                console.log("Enter ref doc description value in description field" + description + "");
                if (isSave) {
                    refDocElementManager.findElement(currentPage, "iconSave").click();
                    return ObjTestHelper.isElementPresent(currentPage, "resultData").then(function (displayed) {
                        expect(displayed).to.equal(true);
                        console.log("Ref Doc saved Successfully");
                    })
                }
                else {
                    console.log("Ref Doc  not saved Successfully");
                }
            }
            else {
                console.log("Text id is not displayed.");
            }
        })

    };
    /**
* searchRefDocById: This function will search RefDoc on Reference document page 
*  * @param Ref Doc Id : Provide the value in Ref Doc Id    
*/
    this.searchRefDocById = function (refDoc) {
        var deferred = protractor.promise.defer();
        browser.sleep(2000);
        promiseUtil.isElementNotDisplayed(refDocElementManager.findElement(currentPage, "txtID")).then(function (displayed) {
            ObjTestHelper.isElementPresent(currentPage, "iconSearch").then(function (isSearchDisplayed) {
                expect(isSearchDisplayed).to.equal(true);
                if (isSearchDisplayed) {
                    refDocElementManager.findElement(currentPage, "iconSearch").click();
                    ObjTestHelper.isElementPresent(currentPage, "txtSearch").then(function (isTxtSearchDisplayed) {
                        expect(isTxtSearchDisplayed).to.equal(true);
                        refDocElementManager.findElement(currentPage, "txtSearch").sendKeys(refDoc);
                        deferred.fulfill(isTxtSearchDisplayed);
                    })
                }
                else {
                    console.log("Enter ref doc value in text Search" + refDoc + "");
                    deferred.fulfill(false);
                }
            })
        })
        return deferred.promise;
    };
    /**
* editRefDoc: This function will edit RefDoc on Reference document page 
*  * @param Ref Doc Id : Provide the updated value in Ref Doc Id  
*/
    this.editRefDoc = function (editRefDoc) {
        return ObjTestHelper.isElementPresent(currentPage, "1stCheckbox").then(function (displayed) {
            refDocElementManager.findElement(currentPage, "1stCheckbox").click();
            refDocElementManager.findElement(currentPage, "editRefDoc").click();
            return ObjTestHelper.isElementPresent(currentPage, "txtID").then(function (displayed) {
                expect(displayed).to.equal(true);
                if (displayed) {
                    var textID = refDocElementManager.findElement(currentPage, "txtID");
                    textID.clear();
                    browser.sleep(1000);
                    textID.sendKeys(editRefDoc);
                    refDocElementManager.findElement(currentPage, "iconSave").click();
                    return ObjTestHelper.isElementPresent(currentPage, "resultData").then(function (displayed) {
                        expect(displayed).to.equal(true);
                        console.log("Ref Doc updated Successfully");
                    })
                }
                else {
                    console.log("Text id is not displayed.");

                }
            })
        })
    };
    /**
     * deleteRefDoc: This function will delete RefDoc on Reference document page 
     * @param Ref Doc Id : Provide the value in Ref Doc Id      
   */
    this.deleteRefDoc = function () {
        refDocElementManager.findElement(currentPage, "1stCheckbox").click();
        refDocElementManager.findElement(currentPage, "deleteRefDoc").click();
        return ObjTestHelper.isElementPresent(currentPage, "btnOK").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("click on delete button");
        })
    };
    /**
    * deleteMsg: This function will validate delete Message            
    */

    this.deleteMsg = function (deleteMsg) {
        var msg = refDocElementManager.findElement(currentPage, "deleteMsg").getText();
        ObjTestHelper.assertEqual(msg, deleteMsg);

    };
    /**
   * delete: This function will click on Ok and cancel to delete the refdoc from the list
   * @param : True or false 
    */
    this.delete = function (isDelete) {
        var deferred = protractor.promise.defer();
        if (isDelete) {
            refDocElementManager.findElement(currentPage, "btnOK").click();
            ObjTestHelper.isElementPresent(currentPage, "noData").then(function (displayed) {
                expect(displayed).to.equal(true);
                deferred.fulfill(displayed);
                console.log("if we click 'Ok'button the Reference Document be deleted from the list");
            });
        }
        else {
            refDocElementManager.findElement(currentPage, "btnCancel").click();
            ObjTestHelper.isElementPresent(currentPage, "resultData").then(function (displayed) {
                expect(displayed).to.equal(true);
                console.log("if we click 'Cancel'button the Reference Document not deleted from the list");
                deferred.fulfill(displayed);
            });
        }
        return deferred.promise;
    };
    /**
    * unLinkRefDoc: This function will unlink RefDoc on Reference document page 
    * @param Ref Doc Id : Provide the value in Ref Doc Id      
  */
    this.unLinkRefDoc = function (isClick) {
        if (isClick) {
            refDocElementManager.findElement(currentPage, "1stCheckbox").click();
        }
        refDocElementManager.findElement(currentPage, "unlinkRefDoc").click();
        return ObjTestHelper.isElementPresent(currentPage, "btnOK").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("click on unlink button");
        })
    };
    /**
    *unLinkMsg: This function will validate unlink Message            
   */
    this.unLinkMsg = function (unLinkedMsg) {
        var msg = refDocElementManager.findElement(currentPage, "unlinkMsg").getText();
        ObjTestHelper.assertEqual(msg, unLinkedMsg);
        console.log("Validate unlink message");
    };
    /**
   * delete: This function will click on Ok and cancel to unlink the refdoc from the list
   * @param : True or false 
    */
    this.unLink = function (isUnlink) {
        var deferred = protractor.promise.defer();
        if (isUnlink) {
            refDocElementManager.findElement(currentPage, "btnOK").click();
            ObjTestHelper.isElementPresent(currentPage, "noData").then(function (displayed) {
                expect(displayed).to.equal(true);
                console.log("if we click 'Ok'button the Reference Document be unlinked from the list");
                deferred.fulfill(displayed);
            })
        }
        else {
            refDocElementManager.findElement(currentPage, "btnCancel").click();
            ObjTestHelper.isElementPresent(currentPage, "resultData").then(function (displayed) {
                expect(displayed).to.equal(true);
                console.log("if we click 'Cancel'button the Reference Document not unlinked from the list");
                deferred.fulfill(displayed);
            })
        }
        return deferred.promise;
    };

    /**
   * linkRefDoc: This function will click on link RefDoc      
   */
    this.linkRefDoc = function () {

        refDocElementManager.findElement(currentPage, "linkRefDoc").click();
        return ObjTestHelper.isElementPresent(currentPage, "txtInput").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("click on link button");
        })
    };
    /**
     * 
   * searchAndLinkRefDoc: This function will search and link RefDoc on Asset finder search 
   * @param Ref Doc Id : Provide the value in Ref Doc Id      
   */
    this.searchAndLinkRefDoc = function (valueToSearch) {
        return ObjTestHelper.isElementPresent(currentPage, "iconSearchFinder").then(function (displayed) {
            expect(displayed).to.equal(true);
            if (displayed) {
                var txtInput = refDocElementManager.findElement(currentPage, "txtInput");
                txtInput.sendKeys(valueToSearch);
                console.log("Entered search value in Asset Finder text box " + valueToSearch + "");
                var iconSearch = refDocElementManager.findElement(currentPage, "iconSearchFinder").click();
                var selectRefDoc = refDocElementManager.findElement(currentPage, "selectRefDoc");
                promiseUtil.isElementDisplayed(selectRefDoc);
                refDocElementManager.findElement(currentPage, "selectRefDoc").click();               
                browser.sleep(1000);
                refDocElementManager.findElement(currentPage, "btnOKFinder").click();
                ObjTestHelper.isElementPresent(currentPage, "resultData").then(function (displayed) {
                    expect(displayed).to.equal(true);
                    console.log("Ref Doc link Successfully");
                })
            }
            else {
                console.log("Text input box not displayed.");
            }
        })

    };

    this.getRandomString = function () {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
        var string_length = 8;
        var randomstring = '';
        for (var i = 0; i <= string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        return randomstring;
    };
};
module.exports = new refDocPage();



