/**
 * Created by ravkumar on 21/12/2017.
 *  * */
'use strict';
var currentPage = "createNewRecord";
function createRecordManager() {
    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var createRecordObjectManager = objectManager.getLocalObjectManager("Foundation", "createNewRecord", currentPage);
    var createRecordElementManager = createRecordObjectManager.ElementManager;
    var ObjTestHelper = createRecordObjectManager.TestHelper;
    var EC = protractor.ExpectedConditions;
    var self = this;
    this.waitTime = 90000;
    var promiseUtilFile = require('../../../Common_Template/PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    /**
     * create New Record: This function will validate Create new Record icon on HomePage 
    */

    this.iconCreateNewRecord = function () {
        return ObjTestHelper.isElementPresent(currentPage, "iconNewRecord").then(function (displayed) {
            expect(displayed).to.equal(true);
            console.log("create New Record icon is present on HomePage");
        })

    };
    /**
     * create New Record: This function will click on create New Record and then it will enter the search value.   
     * @param valueToSearch : Provide the value to be searched in global search!
     * @returns {*}
     */
    this.createNewRecord = function (valueToSearch) {
        var deferred = protractor.promise.defer();
        createRecordElementManager.findElement(currentPage, "iconNewRecord").click();
        ObjTestHelper.isElementPresent(currentPage, "txtSearch").then(function (displayed) {
            expect(displayed).to.equal(true);
            createRecordElementManager.findElement(currentPage, "txtSearch").sendKeys(valueToSearch);
            console.log("Entered search value in create New Record: " + valueToSearch + "");
            ObjTestHelper.isElementPresent(currentPage, "clickRM").then(function (displayed) {
                expect(displayed).to.equal(true);
                deferred.fulfill(displayed);
                createRecordElementManager.findElement(currentPage, "clickRM").click();
                console.log("Record Manager open in UI");
            });
        });
        return deferred.promise;
    };
    /**    
     * save the dataSheet: This function will save  New Record    
     * @param values : Enter the values in Datasheet.
     * @returns {*}
     */
    this.saveDatasheet = function () {
        var deferred = protractor.promise.defer();
        ObjTestHelper.isElementPresent(currentPage, "newEquipmentId").then(function (isEquipmentDisplayed) {
            expect(isEquipmentDisplayed).to.equal(true);
            if (isEquipmentDisplayed) {
                createRecordElementManager.findElement(currentPage, "iconSave").click();
                ObjTestHelper.isElementPresent(currentPage, "parentFamily").then(function (isFamilyDisplayed) {
                    expect(isFamilyDisplayed).to.equal(true);
                    if (isFamilyDisplayed) {
                        console.log("Record Manager is saved");
                    }
                    else {
                        console.log("Record Manager is not saved");
                    }
                    deferred.fulfill(isFamilyDisplayed);
                });
            }
            else {
                console.log("Record Manager is not saved");
                deferred.fulfill(false);
            }
        });
        return deferred.promise;
    };

    /**
    * navigate to Reference Document     
    */
    this.navigateToRefDoc = function () {
        return browser.wait(EC.elementToBeClickable(createRecordElementManager.findElement(currentPage, "iconSave")), self.waitTime).then(function () {
            createRecordElementManager.findElement(currentPage, "moreOptionsInDatasheet").click();
            return browser.wait(EC.elementToBeClickable(createRecordElementManager.findElement(currentPage, "iconRefDoc")), self.waitTime).then(function () {
                return createRecordElementManager.findElement(currentPage, "iconRefDoc").click().then(function () {
                    console.log("navigate to Reference Document");
                })
            })
        })
    };
};

module.exports = new createRecordManager();