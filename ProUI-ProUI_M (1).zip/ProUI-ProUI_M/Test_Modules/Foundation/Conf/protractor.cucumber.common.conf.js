/**
 * Created by 212629051 on 12/21/17.
 */
exports.config = {
    
        // ---- While testing locally
        sauceUser: null,
        sauceKey: null,
        sauceSeleniumAddress: null,    
        directConnect: false,
        firefoxPath: null,
    
        // ---------------------------------------------------------------------------
        // ----- What tests to run ---------------------------------------------------
        // ---------------------------------------------------------------------------
    
        specs: [],
        // Patterns to exclude.
        exclude: [],
    
        // Organize spec files into suites. To run specific suite, --suite=<name of suite>
        suites: {
            refDoc: ['../Features/uiRefDoc.feature'],
            // loginTest: ['../Features/tabs.feature'],
            // loginTest: ['../Features/apmSelect.feature'],
            // loginTest: ['../Features/CreateAnalysis.feature'],
        },
    
        // Hooks running in the background
        plugins: [{
            path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
        }],
    
        capabilities: {
            browserName: 'chrome',
            /*proxy: {
             proxyType: 'manual',
             httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
             sslProxy: 'sjc1intproxy01.crd.ge.com:8080'
             },*/
            count: 1,
            shardTestFiles: false,
            maxInstances: 1,
            'chromeOptions': {
                args: ['--no-sandbox', '--test-type=browser', '--start-maximized'],
                // Set download path and avoid prompting for download even though
                // this is already the default on Chrome but for completeness
                prefs: {
                    'download': {
                        'prompt_for_download': false,
                        'directory_upgrade': true,
                        'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                    }
                }
            }
        }
        ,
    
    
        params: {
            env: 'dev'
        },
    
        maxSessions: -1,
    
        allScriptsTimeout: 250000,
    
        // How long to wait for a page to load.
        getPageTimeout: 650000,
    
        // Before launching the application
        beforeLaunch: function () {
        }
        ,
    
    // Browser parameters for feature files.
        params: {
    
            login: {
                //"baseUrl": "http://blrqavmv430.meridium.com/meridium/index.html",
                //"username": "bl",
                //"password": "bl",
                 //"database": "V4030000_TEST_QA_LAST_ORA"
                "baseUrl": "https://apmrc.int-app.aws-usw02-pr.predix.io/sample-ud",
                "username": "sample-ud-smokeuser",
                "password": "Pa55w0rd"
            }
        },
    
        // Application is launched but before it starts executing
        onPrepare: function () {
    
            // Create reports folder if it does not exist
            var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
            var mkdirp = require('mkdirp');
            var reportsPath = "./Reports/";
    
            mkdirp(reportsPath, function (err) {
                if (err) {
                    console.error(err);
                } else {
                }
            });
    
            browser.manage().deleteAllCookies();
            browser.manage().timeouts().pageLoadTimeout(50000);
            browser.manage().timeouts().implicitlyWait(50000);
            // browser.driver.manage().window().setSize(1280, 1440);
    
            chai = require('chai');
            expect = chai.expect;
            path = require('path');
            Cucumber = require('cucumber');
            fs = require('fs');
    
    
            // This is declaration for Object Manager
            objectManagerFile = require('proui-utils').ObjectManager;
            objectManager = new objectManagerFile();
    
            // This is declation for SearchManager
            searchManagerFile = require('../../../Common_Template/PageObjects/global-search-po.js');
            searchManager = new searchManagerFile();
    
            // Initializing page object variables
            dataSheetFile = require('../../../Common_Template/PageObjects/datasheet-po.js');
            loginUnified = require('../../../Common_Template/PageObjects/login-po.js');
            apmlandingPage = require('../../../Common_Template/PageObjects/apm-landing-po.js');
            wfvPage = require('../../../Common_Template/PageObjects/wfv-po.js');
            assetTenantPage = require('../../../Common_Template/PageObjects/asset-tenant-po.js');
    
            // nvaigation will be available to everywhere
            navigation = require('../../../Common_Template/PageObjects/navigation-po.js');
            menus = require('../../../Common_Template/TestData/menus.js');
    
            tabsUtility = require('../../../Common_Template/PageObjects/tabs-po.js');
            tabPO = new tabsUtility();
    
            apmSelect = require('../../../Common_Template/PageObjects/apm-select-po.js');
    
            login = require('../../../Common_Template/PageObjects/login-po.js');            
            Logger = require('ProUI-Utils').Logger;
            RestHelper = require('ProUI-Utils').RestHelper;
            TestHelper = require('proui-utils').TestHelper;
            createRecordManager = require('../PageObjects/createRecordManager-po.js');
            refDocPage = require('../PageObjects/refDocPage-po.js');
        } 
        ,
    
    
    // A callback function called once tests are finished
        onComplete: function () {
        }
        ,
    
    // A callback function called once tests are cleaning up
        onCleanUp: function (exitCode) {
    
        }
        ,
    
    // A callback function after tests are launched
        afterLaunch: function () {
    
        }
        ,
        resultJsonOutputFile: null,
    
        // If true, protractor will restart the browser between each test.
        // CAUTION: This will cause your tests to slow down drastically.
        restartBrowserBetweenTests: false,
    
        // Custom framework in this case cucumber
        framework: 'custom',
        frameworkPath: require.resolve('protractor-cucumber-framework'),
        cucumberOpts: {
    
            // define your step definitions in this file
            require: [
                '../../../Common_Template/step_definitions/login-step-def.js',
                '../../../Common_Template/step_definitions/env.js',
                '../../../Common_Template/step_definitions/login-spec.js',
                '../../Test_Modules/Assets/step_definitions/*',
                '../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
                '../../Test_Modules/Highchart/step_definitions/*',
                '../../Test_Modules/RestAPIExample/step_definitions/rest-example-step-def-highchart.js',
                '../../Test_Modules/RestAPIExample/step_definitions/rest-example-step-def.js',
                '../../Test_Modules/SinglePage/Step_Definitions/singlepage-step-def.js',
                '../step_definitions/*',
                '../../Test_Modules/Foundation/step_definitions/*',
                '../../Test_Modules/Foundation/*'
            ],
    
            //format: 'pretty'
        }
    }
    ;
    