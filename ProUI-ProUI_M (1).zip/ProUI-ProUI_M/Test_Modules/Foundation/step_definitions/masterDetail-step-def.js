'use strict';
var masterDetailStepDefinitions = function () {
var refDocPage = require('../PageObjects/refDocPage-po.js');
var createRecordManager = require('../PageObjects/createRecordManager-po.js');
var masterDetail = require('../PageObjects/masterDetail-po.js');
//var apmSelectFile = require('../../../Common_Template/PageObjects/selectAPM.js');
//apmSelect = new apmSelectFile(element(by.tagName('mi-select')));
var charId="Test Char"+refDocPage.getRandomString();
//var num=getRandomString();
var text="Text"+refDocPage.getRandomString();
var family="AQA Master for MDF";
var dataSheet="AQA Master Detail";
var dataSheet1="AQA MD Security Deny Delete";
var dataSheet2="AQA MD Security Deny Delete, Insert";
var dataSheet3="AQA MD Security Deny Delete, Insert, Edit";
var dataSheet4="AQA MD Security Deny Delete, Edit";


this.Given(/^Login to Application$/, function (callback){
    browser.ignoreSynchronization = true;
    login.navigateAndLogin().then(function (){
    callback();
    })
});

// this.When(/^Create New Record icon available on HomePage$/, function (callback){
//     createRecordManager.iconCreateNewRecord().then(function (){
//     callback();
//     })            
// });
// this.Then(/^Create New Record AQA Master for MDF$/, function (callback){
//     createRecordManager.createNewRecord(family).then(function (){
//     callback();
//     })            
// });

// this.Then(/^Select DataSheet AQA Master Detail from the dropdown$/, function (callback){
//     apmSelect.selectByText(dataSheet).then(function (){
//     callback();
//     })            
// });

// this.Then(/^we Observe 2 sections in the record manager - Master family and Detail family$/, function (callback){
//     masterDetail.tabMaster("Master").then(function (){
//     callback();
//     })            
// });

// this.Then(/^Enter the details in Master tab$/, function (callback){
//     masterDetail.EnterDetailsInMaster(charId,num,text).then(function (){
//     callback();
//     })            
// });

// this.Then(/^Save the Record$/, function (callback) {
//     masterDetail.saveDatasheet().then(function (){
//     callback();
//     })      
            
// });
// this.Then(/^Validate the saved record$/, function (callback) {
//     masterDetail.validateDatasheet(charId).then(function (){
//     callback();
//     })      
            
// });
// this.Then(/^Navigate to Detail form$/, function (callback) {
//     masterDetail.navigateToDetail().then(function (){
//     callback();
//     })      
            
// });


 
};
module.exports = masterDetailStepDefinitions;