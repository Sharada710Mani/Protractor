var refdocUIStepDefinitions = function () {
    var refDocPage = require('../PageObjects/refDocPage-po.js');
    var createRecordManager = require('../PageObjects/createRecordManager-po.js');
    var refDoc = "Test Ref Doc" + refDocPage.getRandomString();
    var updatedRefDoc = "Updated Ref Doc" + refDocPage.getRandomString();

    this.Given(/^Test Login to Application$/, function (callback) {
        browser.ignoreSynchronization = true;
        login.navigateAndLogin().then(function () {
            callback();
        })
    });
    this.When(/^Create New Record icon available on HomePage$/, function (callback) {
        createRecordManager.iconCreateNewRecord().then(function () {
            callback();
        })
    });
    this.Then(/^Create New Record Equipment$/, function (callback) {
        createRecordManager.createNewRecord("Equipment").then(function () {
            callback();
        })
    });
    this.Then(/^Save the Record$/, function (callback) {
        createRecordManager.saveDatasheet().then(function () {
            callback();
        })
    });
    this.Then(/^Click on icon Moreoptions and navigate to Reference Document$/, function (callback) {
        createRecordManager.navigateToRefDoc().then(function () {
            callback();
        })
    });
    this.Then(/^Validate icon link on Ref Doc UI$/, function (callback) {
        refDocPage.linkRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^Validate Icon Search  on Ref Doc UI$/, function (callback) {
        refDocPage.iconSearchUI().then(function () {
            callback();
        })

    });
    this.Then(/^Validate icon Unlink on Ref Doc UI$/, function (callback) {
        refDocPage.unlinkRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^Validate icon Delete on Ref Doc UI$/, function (callback) {
        refDocPage.deleteRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^Validate icon Edit on Ref Doc UI$/, function (callback) {
        refDocPage.editRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^Validate Column details on Ref Doc UI$/, function (callback) {
        refDocPage.validateColInRefDoc().then(function () {
            callback();
        })
    });


    this.Given(/^The Add Reference Document button is loaded on the page$/, function (callback) {
        refDocPage.addRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^I can able to Add Reference Document without Document Path$/, function (callback) {
        refDocPage.createRefDoc(refDoc, "Test Ref Doc description", true).then(function () {
            callback();
        })
    });
    this.Given(/^The newly created Reference Document  saved successfully$/, function (callback) {
        refDocPage.iconSearchUI().then(function () {
            callback();
        })
    });
    this.Then(/^I can see added Reference Document will come in the list after saving - without screen refresh$/, function (callback) {
        refDocPage.searchRefDocById(refDoc).then(function () {
            callback();
        })
    });

    this.Given(/^The Edit button available on Reference Document Page$/, function (callback) {
        refDocPage.editRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^Select and update the Reference Document in the list$/, function (callback) {
        refDocPage.editRefDoc(updatedRefDoc).then(function () {
            callback();
        })
    });
    this.Then(/^I can see the updated Reference Document will come in the list$/, function (callback) {
        refDocPage.searchRefDocById(updatedRefDoc).then(function () {
            callback();
        })
    });
    this.Given(/^The Unlink button available on Reference Document Page$/, function (callback) {
        refDocPage.unlinkRefDocUI(true).then(function () {
            callback();
        })
    });
    this.Then(/^click on Unlink icon to Unlink Reference Document from the list$/, function (callback) {
        refDocPage.unLinkRefDoc(true).then(function () {
            callback();
        })
    });
    this.Then(/^Alert Message Are you sure you want to unlink this reference document$/, function (callback) {
        refDocPage.unLinkMsg("Are you sure you want to unlink selected entities?");
        callback();
    });
    this.Then(/^I Click Cancel button,the Reference Document not be Unlinked from the list$/, function (callback) {
        refDocPage.unLink(false).then(function () {
            callback();
        })
    });
    this.Then(/^Again click on Unlink icon to Unlink Reference Document from the list$/, function (callback) {
        refDocPage.unLinkRefDoc().then(function () {
            callback();
        })
    });
    this.Then(/^I click Ok button the Reference Document be unlinked from the list$/, function (callback) {
        refDocPage.unLink(true).then(function () {
            callback();
        })
    });

    this.Given(/^The link button available on Reference Document Page$/, function (callback) {
        refDocPage.linkRefDocUI().then(function () {
            callback();
        })
    });

    this.Then(/^click on link icon to link Reference Document$/, function (callback) {
        refDocPage.linkRefDoc().then(function () {
            callback();
        })
    });

    this.Then(/^search the Reference Document and link to family$/, function (callback) {
        refDocPage.searchAndLinkRefDoc(updatedRefDoc).then(function () {
            callback();
        })
    });
    this.Then(/^I can Observe the Reference Document added in the list$/, function (callback) {
        refDocPage.searchRefDocById(updatedRefDoc).then(function () {
            callback();
        })
    });


    this.Given(/^The Delete button visible on Reference Document Page$/, function (callback) {
        refDocPage.deleteRefDocUI().then(function () {
            callback();
        })
    });
    this.Then(/^Delete the Reference Document$/, function (callback) {
        refDocPage.deleteRefDoc().then(function () {
            callback();
        })
    });
    this.Then(/^Alert Message Are you sure you want to delete selected entities$/, function (callback) {
        refDocPage.deleteMsg("Are you sure you want to delete selected entities?");
        callback();
    });
    this.Then(/^I click Ok button the Reference Document be deleted from the list$/, function (callback) {
        refDocPage.delete(true).then(function () {
            callback();
        })
    });
    this.Then(/^I can Observe the Reference Document deleted from the list$/, function (callback) {
        refDocPage.searchRefDocById(updatedRefDoc).then(function () {
            callback();
        })
    });

};
module.exports = refdocUIStepDefinitions;

