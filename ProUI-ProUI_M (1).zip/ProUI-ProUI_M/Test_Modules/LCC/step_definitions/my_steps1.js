// var myHomePage = require('../PageObjects/HomePage-po.js');
var lccPage = require('../PageObjects/LCC-po.js');

module.exports = function () {
 this.setDefaultTimeout(100*1000);
// var my1 = new myHomePage();
    this.Then(/^We navigate to the LCC page$/, function (callback) {
        myHomePage.goToLCC();
        // browser.sleep(5000);
        callback();


    });

    this.Then(/^we make sure, we are on the correct page$/, function (callback) {
        lccPage.verifyHeader().then(function(output){
            console.log("Finally we have clicked$$$$$$$$$$$$$$$$44" + output);
            callback();
        });


    });

    this.Given(/^We login to the application$/, function (callback) {
        browser.ignoreSynchronization = true;
        browser.get("http://blrqavm3/meridium/index.html").then(function () {
            browser.driver.findElement(by.id('userid')).isDisplayed().then(function () {
                browser.driver.findElement(by.id('userid')).sendKeys("bl").then(function () {
                    browser.driver.findElement(by.id('password')).sendKeys("bl").then(function () {
                        browser.driver.findElement(by.xpath("//select//option[text()='" + "V4030001_TEST_WED_ORA" + "']")).click().then(function () {
                            browser.driver.findElement(by.xpath("//span[text()='Sign-in']")).click().then(function () {
                                // myHomePage.goToLCC();
                                browser.sleep(10000);
                                callback();
                            })


                        });

                    })
                })
            })
        });


        /*
         login.getLoginPage().then(function () {
         browser.sleep(3000);
         login.setName("bl").then(function () {
         login.setPassword("bl").then(function () {
         login.setDatabase("V4030001_TEST_WED_ORA").then(function () {
         login.clickLogin().then(function () {
         console.log("Login button clicked");
         });
         });
         });
         });


         });*/

    });
};

