var tabsStepDefinitions = function () {
    this.Given(/^Using Tab functionality$/, function (callback) {
        browser.ignoreSynchronization = true;

        login.navigateAndLogin();

        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis);
        navigation.navigateToScreen(menu.integrity, subMenu.integrityHazardsAnalysis);
        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis);
        navigation.navigateToScreen(menu.integrity, subMenu.integrityInspectionManagement);

        tabPO.closeAllTabs().then(function(){
            console.log("All tabs are closed:");
        })

        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis)
        navigation.navigateToScreen(menu.integrity, subMenu.integrityHazardsAnalysis);
        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis);
        navigation.navigateToScreen(menu.integrity, subMenu.integrityInspectionManagement);
        browser.sleep(5000);

        tabPO.getAllTabs().then(function(list){
            for(var i=0;i<list.length;i++)
            {
                list[i].getAttribute('title').then(function(text){ console.log("Tab text is:"+text);})
            }
        })

        tabPO.getAllTabsText().then(function(list){
            for(var i=0;i<list.length;i++)
            {
                console.log("Tab text is:"+list[i]);
            }
        })

        tabPO.getTabs('LOPA Overview').then(function(list){
            console.log('There are '+list.length+' LOPA Overview tab(s) opened.')
        })

        tabPO.getCurrentTab().then(function(data){ data.getAttribute('title').then(function(text){ console.log("Current tab text is:"+text);})})

        tabPO.getCurrentTabText().then(function(text){console.log("Current tab text is:"+text);})

        tabPO.closeCurrentTab().then(function(status){
            console.log(status);
            console.log("Current tab is closed:");
        })

        tabPO.selectTab('Hazards Analysis Overview').then(function(status){
            console.log(status);
            console.log("Hazards Analysis Overview tab is selected");
        })

        tabPO.closeTab('LOPA Overview').then(function(status){
            console.log(status);
            console.log("LOPA Overview tab is closed:");
            callback();
        })
        /* Tab testing ends here */
    });
};
module.exports = tabsStepDefinitions;

