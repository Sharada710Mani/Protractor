var tempPo = require('../PageObjects/tempPO.js')

var myStepDefinitionsWrapper = function () {
    this.Given(/^We will login$/, function (callback) {
        browser.ignoresynchronization = true;
        browser.get("http://blrqavm3/meridium/index.html").then(function () {
            element(by.xpath("//input[@id='userid']")).sendKeys("bl").then(function () {
                element(by.xpath("//input[@id='password']")).sendKeys("bl").then(function () {
                    element(by.xpath("//select//option[text()='" + "V4030001_TEST_THU_ORA" + "']")).click().then(function () {
                        element(by.xpath("//span[text()='Sign-in']")).click();
                        browser.sleep(4000);
                        callback();
                    })
                })
            })
        });
    });

    this.When(/^Go to the LCC page$/, function (callback) {
        tempPO.goToLCC();

        callback();
    });

    this.Then(/^Click on New Analylsis button avaailable there$/, function (callback) {
        tempPo.clickNewAnalysis();
        callback();
    });
    this.Then(/^And Validate we are on the correct page$/, function (callback) {
        console.log("WE are done!");
        callback();
    });
};
module.exports = myStepDefinitionsWrapper;