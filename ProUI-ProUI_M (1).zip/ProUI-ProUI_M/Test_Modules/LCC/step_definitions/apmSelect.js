var selectAPMStepDefinitions = function () {
    this.Given(/^Using APM Select functionality$/, function (callback) {
        browser.ignoreSynchronization = true;
        login.navigateAndLogin();

        /*  APMSelect starts here */
        navigation.navigateToScreen(menu.admin, subMenu.adminApplicationSettings)
        var lnkCM = element(by.xpath("//a[text()='Calibration Management']"));
        var mnuStrategies = element(by.xpath("//div[@class='left-section-nav block']//li[text()='Strategies']"));
        var btnStrategy = element(by.xpath("//a[text()='2U']"));
        var listElement = element(by.xpath("//div[@data-controlname='MI_CALSTRAT_TEMP_TYPE_C']//mi-select"));

        lnkCM.isDisplayed().then(function(){lnkCM.click()});
        mnuStrategies.isDisplayed().then(function(){mnuStrategies.click()});
        btnStrategy.isDisplayed().then(function(){btnStrategy.click()});

        // Select part starts here
        listElement.isDisplayed().then(function() {
            var listBox = new apmSelect(listElement)

            listBox.open().then(function () {
                console.log('APM select is opened.')
            })
            listBox.close().then(function () {
                console.log('APM select is closed.')
            })

            listBox.getAllOptions().then(function(list){
                console.log('getAllOptions:Printing all option  text')
                for(var i=0;i<list.length;i++)
                {
                    list[i].getAttribute('innerText').then(function(text){ console.log("Option item text:"+text) })
                }
            })

            listBox.getAllOptionsText().then(function(list){
                console.log('getAllOptionsText:Printing all option text')

                for(var i=0;i<list.length;i++)
                {
                    console.log("Option item text:"+list[i])
                }
            })

            listBox.getAllSelectedOptions().then(function(list){
                console.log('getAllSelectedOptions:Printing all selected option text')
                for(var i=0;i<list.length;i++)
                {
                    list[i].getAttribute('innerText').then(function(text){ console.log("Selected option item text:"+text) })
                }
            })

            listBox.getAllSelectedOptionsText().then(function(list){
                console.log('getAllSelectedOptionsText:Printing all selected option text')
                for(var i=0;i<list.length;i++)
                {
                    console.log("Selected item text:"+list[i])
                }
            })

            listBox.getAllCount().then(function(data){
                console.log('Total item count is:'+data);
            })

            listBox.getAllSelectedCount().then(function(count){
                console.log('Total selected item count is:'+count);
            })

            listBox.isMultiple().then(function(elementType){
                if(elementType)
                    console.log('Element is ListBox');
                else
                    console.log('Element is Dropdown');
            })


            // Functions specific to list box.
            listBox.deselectByIndex(1).then(function(){
                console.log('1st index item is de-selected')
            })

            listBox.deselectByPartialText('Single').then(function(){
                console.log('Single Component Analyzer is de-selected')
            })
            listBox.getSelectedOptionText().then(function(text){
                console.log('Selected item text is:'+text);
            })
            listBox.getSelectedOption().then(function(option){option.getAttribute('innerText').then(function(text){
                console.log('Selected option text is:'+text); })
            })
            listBox.selectByPartialText('Single').then(function(){
                console.log('Single Calibration is selected')
            })
            listBox.deselectAll().then(function(){
                console.log('All items are de-selected')
                callback();
            })
        });
        /* APM Select ends here */

    });
};
module.exports = selectAPMStepDefinitions;

