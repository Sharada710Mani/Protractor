module.exports = function () {
    this.Given(/^The application is loggedin$/, function (callback) {
        login.checklogoutButton().then(function (completed) {
            Logger.info("Asserting if logged in\n");
            TestHelper.assertTrue(completed, 'Not logged in');
            callback();
        });
    });


    this.When(/^User Navigate to the LCC screen$/, function (callback) {
        homePageLCC.navigateToLCC().then(function (completed) {
            assert.isTrue(completed,'Did not click');
            callback();
        });

    });
};