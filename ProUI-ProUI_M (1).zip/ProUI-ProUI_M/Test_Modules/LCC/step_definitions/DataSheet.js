var myStepDefinitionsWrapper = function () {
        var DSObjectManager = objectManager.getLocalObjectManager("LCC", "test", "test");
        var lem = DSObjectManager.ElementManager;
        var th = DSObjectManager.TestHelper;
        var ObjdataSheet = new dataSheetFile(DSObjectManager);
    
        this.Given(/^Login To The Unified Part$/, function (callback) {
           //loginUnified.loginToUnified();
            browser.ignoreSynchronization = true;
            login.navigateAndLogin();
            callback();
    
        });
    
        this.Then(/^Open any existing datasheet$/, function (callback) {
            navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis);
            browser.findElement(by.xpath("//button[text()='New Analysis']")).click().then(function () {
                console.log("All steps completed sucessfully");
                callback();
            });
        });
    
        this.Then(/^Test All the exsitng functions written$/, function (callback) {
            ObjdataSheet.enterDataInTextBox("newAnalysisId", "AnalysiID").then(function () {
                browser.sleep(2000);
            })
    
            ObjdataSheet.prependDataInTextBox("newAnalysisId", "Mr. ").then(function () {
                browser.sleep(2000);
            })
    
            ObjdataSheet.appendDataInTextBox("newAnalysisId", " is rocking").then(function () {
                browser.sleep(2000);
            })
            // dataSheet.enterDataInTextBox("Unit ID: ","Shastri Ji Unit id");
    
            ObjdataSheet.enterDataInTextArea("scope", "Text Area Value").then(function () {
                browser.sleep(2000);
            });
    
            ObjdataSheet.prependDataInTextArea("scope", "prepend ").then(function () {
                browser.sleep(2000);
            });
    
            ObjdataSheet.enterDataInTextArea("scope", " append").then(function () {
                browser.sleep(2000);
            });
    
    
            ObjdataSheet.clearTextBox("newAnalysisId").then(function () {
                browser.sleep(2000);
            })
    
            ObjdataSheet.clearTextArea("scope").then(function () {
                console.log("Waiting for Exit!!!!");
                browser.sleep(10000).then(function () {
                callback();
                })
            })
        });
    };
    module.exports = myStepDefinitionsWrapper;
    