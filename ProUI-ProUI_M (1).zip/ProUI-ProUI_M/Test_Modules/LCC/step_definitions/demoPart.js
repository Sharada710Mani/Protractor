var myStepDefinitionsWrapper = function () {
    this.Given(/^Demo part here$/, function (callback) {
        var lccObjectManager = objectManager.getLocalObjectManager("LCC", "demoPart", "demoPart");
        var lem = lccObjectManager.ElementManager;
        var dataSheet = new dataSheetFile(lccObjectManager);
        browser.ignoreSynchronization = true;
        login.navigateAndLogin();
        navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis);

        lem.findElement("demoPart", "newAnalysis").click().then(function () {
            console.log("We have clicked the New Analysis button");
        });

        dataSheet.enterDataInTextBox("newAnalysisId", "Test");//Unique Value
        dataSheet.enterDataInTextArea("scope");

        // Save the Analysis
        lem.findElement("demoPart", "save").click();

        // Search this element via global search
        searchManager.globalSearch("Test Analysis", "Test Analysis");

        browser.sleep(5000).then(function () {
            console.log("We have waited before leaving");
        });


        lccObjectManager = objectManager.getLocalObjectManager("LCC", "test","test");
        lem = lccObjectManager.ElementManager;
        dataSheet = new dataSheetFile(lccObjectManager);


        navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis);
        lem.findElement("test", "newAnalysis").click().then(function () {
            console.log("We have clicked the New Analysis button");

        });

        dataSheet.enterDataInTextBox("newAnalysisId", "Analysis355").then(function () {//Unique Value
            browser.sleep(1000);
        });
        dataSheet.enterDataInTextArea("scope");
        lem.findElement("test", "save").click();


        lccObjectManager = objectManager.getCommonObjectManager("LCC", "AnalysisLCC","AnalysisLCC");
        lem = lccObjectManager.ElementManager;
        dataSheet = new dataSheetFile(lccObjectManager);


        navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis);
        lem.findElement("AnalysisLCC", "newAnalysis").click().then(function () {
            console.log("We have clicked the New Analysis button");


        });

        browser.sleep(5000).then(function () {
            console.log("We have waited before leaving");
        });


        dataSheet.enterDataInTextBox("newAnalysisId", "Test532");//Unique value
        dataSheet.enterDataInTextArea("scope");
        lem.findElement("AnalysisLCC", "save").click();


        callback();

    });
};
module.exports = myStepDefinitionsWrapper;