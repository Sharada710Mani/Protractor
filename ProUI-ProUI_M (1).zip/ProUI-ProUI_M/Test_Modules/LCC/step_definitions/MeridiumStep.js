var currentPage = "tempDelete";

var readFunction = require("../../LCC/PageObjects/readData.js");

var myStepDefinitionsWrapper = function () {
    this.Given(/^Login to Meridium$/, function (callback) {
        loginM.loginWithAdminRights().then(function () {
            console.log("We have logged in to the applicaiton!!!!");
            callback();
        });
    });

    this.Then(/^Navigate to Some Page in the applicaiton for data entry$/, function (callback) {
        console.log("We are into the second step");
        cem.findElement(currentPage, "health").click().then(function () {
            cem.findElement(currentPage, "ACA").click().then(function () {
                cem.findElement(currentPage, "newAnalysis").click().then(function () {
                    browser.sleep(3000);
                    callback();
                })
            })
        });
    });

    this.Then(/^Enter data in the text area and text box with the data entry functionality$/, function (callback) {
        readFunction.readData("HomePage", "reliability");





      //  dataSheet.enterDataInTextBox("Analysis ID: ", "Analysis Id");

       // dataSheet.appendDataInTextBox("Analysis ID: ", "This is my Appended Value");




        console.log("Use the data entry utility");
       // cem.findElement(currentPage, "dataSheetTitle");
       // browser.sleep(10000).then(function () {
        //    console.log("Sleeping again");
         //   callback();
        //});


    });
};
module.exports = myStepDefinitionsWrapper;