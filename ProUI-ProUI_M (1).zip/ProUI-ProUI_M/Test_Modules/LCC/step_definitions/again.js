var myStepDefinitionsWrapper = function () {
    this.Given(/^This will contain all the stpes$/, function (callback) {
        browser.ignoreSynchronization = true;

        login.navigateAndLogin();
        var objManager = objectManager.getLocalElementManager("LCC","demoeee","sd");
        var lem = objManager.ElementManager;
        var tem = objManager.TestHelper;

        dataSheet.enterDataInTextBox()
        callback();
    });
};
module.exports = myStepDefinitionsWrapper;