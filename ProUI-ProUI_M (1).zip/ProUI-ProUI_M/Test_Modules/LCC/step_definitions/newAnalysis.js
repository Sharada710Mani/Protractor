var myStepDefinitionsWrapper = function () {
    this.Given(/^Lets do some testing$/, function (callback) {
        var objManger = objectManager.getLocalElementManager("LCC", "abc");
        var lem = objManger.ElementManager;

        browser.ignoreSynchronization = true;
        login.navigateAndLogin();
        navigation.navigateToScreen(menu.health,subMenu.healthAssetCriticalityAnalysis);
        lem.findElement("abc","newAnalysis").click().then(function(){
            console.log("Just clicked the New Analysis button.");

        });

        dataSheet.enterDataInTextBox(objManger,"newAnalysisId", "This is my override value" );
        dataSheet.enterDataInTextArea(objManger,"scope" );

        lem.findElement("abc","save").click().then(function(){
            console.log("Just clicked the New Analysis button.");

        });

        searchManager.globalSearch("This is my override value","This is my override value");






        callback();
    });
};
module.exports = myStepDefinitionsWrapper;