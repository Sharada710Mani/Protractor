//var ProjDemoPO = require('../PageObjects/ProjDemoPO.js')



var myStepDefinitionsWrapper = function () {
    this.Given(/^Login to the APM Application$/, function (callback) {
        // Voilation of POM


        browser.ignoreSynchronization =true;
        browser.get("http://blrqavm3/meridium/index.html").then(function(){
            element(by.xpath("//input[@id='userid']")).sendKeys("bl").then(function(){
                element(by.xpath("//input[@id='password']")).sendKeys("bl").then(function(){
                    element(by.xpath("//select//option[text()='" + "V4030001_TEST_THU_ORA" + "']")).click().then(function(){
                        element(by.xpath("//span[text()='Sign-in']")).click();
                        callback();
                    })
                })
            })
        });
    });

    this.When(/^I go to LCC Page$/, function (callback) {
        ProjDemoPO.goToLCCPage();
        callback();
    });

    this.Then(/^I click on New Analysis button$/, function (callback) {

        ProjDemoPO.newAnalysis();

        callback();
    });
};
module.exports = myStepDefinitionsWrapper;