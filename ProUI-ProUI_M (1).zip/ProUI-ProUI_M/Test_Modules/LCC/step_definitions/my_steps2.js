
// var firstValue= dataFile.lcc.locatorType;




// dataSheet.appendDataInTextArea("lcc","locatorType");

var LandingPagePO = require('../PageObjects/Landing.js')
var lccPagePo = require('../PageObjects/LCCPage.js')


var myStepDefinitionsWrapper = function () {
    this.When(/^We login to the application for this test case$/, function (callback) {
        browser.ignoreSynchronization = true;
        browser.get("http://blrqavm3/meridium/index.html").then(function () {
            element(by.id("userid")).sendKeys("bl").then(function () {
                element(by.id("password")).sendKeys("bl").then(function () {
                    element(by.xpath("//select//option[text()='" + "V4030001_TEST_THU_ORA" + "']")).click().then(function () {
                        element(by.xpath("//span[text()='Sign-in']")).click().then(function () {
                            browser.sleep(5000);
                            callback();
                        });

                    })
                })
            })
        });
    });

    this.When(/^We navigate toe the LCC page for this test case$/, function (callback) {
        LandingPagePO.goToLCC();

        callback();
    });

    this.When(/^Validate we are on the correct page$/, function (callback) {
        lccPagePo.newAnalysis().then(function(){
        console.log("WE have clicked the elemtn");
            callback();
        });




    });

    this.Then(/^We are on the LCC New Analysis Page$/, function (callback) {
        lccPagePo.validateAnalylsis().then(function(value){
            console.log("Validated dddddddddddddddddd " + value);
            callback();
        });

    });
};
module.exports = myStepDefinitionsWrapper;