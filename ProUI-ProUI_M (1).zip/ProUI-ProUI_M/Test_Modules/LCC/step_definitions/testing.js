var myStepDefinitionsWrapper = function () {
    this.Given(/^Login to Application$/, function (callback) {
        browser.ignoreSynchronization = true;
        //browser.get("https://www.google.co.in").then(function(){
        //    console.log("Done something *************************************************************");
        // });
        // browser.sleep(10000);

        login.getLoginUnified().then(function (completed) {
            console.log("Value of the completed is:" + completed);
            // assert.isTrue(completed, 'Not login page');
            callback();
        });
    });


    this.Given(/^Enter Username and Password$/, function (callback) {
        var userName = browser.params.login.usernameUnified;
        var password = browser.params.login.passwordUnified;
        console.log(userName);
        console.log(password);
        login.setUserName(userName).then(function () {
            console.log("User name is set");
            login.setUserPassword(password)
                .then(function () {
                    login.clickAPMLogin().then(function () {
                        callback();
                    });
                });
        });
    });

    this.When(/^We navigate to some of the page available$/, function (callback) {
        browser.sleep(20000);
        navigation.navigateToScreen(Menu.Health, SubMenu.HealthAssetCriticalityAnalysis);
        browser.findElement(by.xpath("//button[text()='New Analysis']")).click().then(function () {
            console.log("All steps completed sucessfully");
            callback();
        });
    });
};
module.exports = myStepDefinitionsWrapper;