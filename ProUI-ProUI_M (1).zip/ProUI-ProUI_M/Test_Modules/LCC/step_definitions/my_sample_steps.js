//var myStepDefinitionsWrapper = function () {
//    // Initialize Object Manager to use existing Pro UI functionalities. Also this will define the repository file to intrect with.
//
//
//
//
//    this.Given(/^Sample function usage$/, function (callback) {
//        var lem = objectManager.getLocalElementManager("LCC", "delete");
//
//        TestHelper = require('proui-utils').TestHelper;
//        TestHelper.setElementManager(lem);
//
//        browser.ignoreSynchronization = true;
//        login.navigateAndLogin();
//
//      /*  navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis);
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityHazardsAnalysis);
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis);
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityInspectionManagement);
//
//        tabs.closeAllTabs(5000).then(function () {
//            console.log("All tabs are closed:");
//        })
//
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis)
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityHazardsAnalysis);
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityLayersofProtectionAnalysis);
//        navigation.navigateToScreen(menu.integrity, subMenu.integrityInspectionManagement);
//
//
//        // Print all the open tabs title text!!
//        tabs.getAllTabs().then(function (list) {
//            for (var i = 0; i < list.length; i++) {
//                list[i].getAttribute('title').then(function (text) {
//                    console.log("Tab text is:" + text);
//                })
//            }
//        })
//        tabs.getTabs('LOPA Overview').then(function (list) {
//            console.log('There are ' + list.length + ' LOPA Overview tab(s) opened.')
//        })
//
//        tabs.getCurrentTab().then(function (data) {
//            data.getAttribute('title').then(function (text) {
//                console.log("Current tab text is:" + text);
//            })
//        })
//        tabs.closeCurrentTab().then(function () {
//            console.log("Current tab is closed:");
//        })
//        tabs.selectTab('Hazards Analysis Overview').then(function () {
//            console.log("Hazards Analysis Overview tab is selected");
//        })
//        tabs.closeTab('LOPA Overview').then(function () {
//            console.log("LOPA Overview tab is closed:");
//        })
//
//*/
//       lem = objectManager.getLocalElementManager("LCC", "delete");
//        ElementManager = require('proui-utils').ElementManager;
//
//
//
//        // TestHelper.setElementManager(new ElementManager('../../../Test_Modules/LCC/Repository/delete.json'));
//        // TestHelper.setElementManager();
//        navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis);
//
//        lem.findElement("delete","NAButton").click();
//
//
//        browser.sleep(1000).then(function () {
//            console.log("Wait for some time here");
//        });
//
//        TestHelper.elementToBeClickable("delete","hide").then(function(){
//            console.log("We did nbt");
//        })
//
//        TestHelper.titleIs("Asset Criticality Analysis").then(function(){
//            console.log("Title  found");
//        },function(){
//            console.log("Title not found");
//        });
//
//
//
//
//       // lem.isElementPresent("delete", "element");
//
//
//        dataSheet.enterDataInTextBox(objectManager, "AnalysisID").then(function () {
//            console.log("First enter");
//        });
//        dataSheet.appendDataInTextBox(objectManager, "Append").then(function () {
//            console.log("Appended Here");
//        });
//
//        dataSheet.prependDataInTextBox(objectManager, "AnalysisIDPrepend");
//
//
//        dataSheet.enterDataInTextArea(objectManager, "area");
//
//        dataSheet.appendDataInTextArea(objectManager, "areaappeand");
//
//        dataSheet.prependDataInTextArea(objectManager, "areaappeandPrepend");
//
//
//        callback();
//    });
//};
//module.exports = myStepDefinitionsWrapper;