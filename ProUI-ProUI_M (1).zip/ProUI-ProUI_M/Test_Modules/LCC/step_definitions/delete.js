/*
var myStepDefinitionsWrapper = function () {
    // var globalManager = objectManager.getGlobalElementManager("junk", "junk");
    // console.log("This is the staring point");



    // var commonObjManager = objectManager.getCommonElementManager("LCC","common");

    this.Given(/^We will be deleting this also$/, function (callback) {

        var lem = objectManager.getLocalElementManager("LCC", "delete");

        loginM.loginWithAdminRights();
        navigation.navigateToScreen(Menu.Health, SubMenu.HealthAssetCriticalityAnalysis);

        element(by.buttonText("New Analysis")).click().then(function () {
            console.log("we have clicked button new analysis!!");
        });
        dataSheet.enterDataInTextBox(objectManager, "AnalysisID").then(function () {
            console.log("First enter");
        });
        dataSheet.appendDataInTextBox(objectManager, "Append").then(function () {
            console.log("Appended Here");
        });

        dataSheet.prependDataInTextBox(objectManager, "AnalysisIDPrepend");


        dataSheet.enterDataInTextArea(objectManager, "area");

        dataSheet.appendDataInTextArea(objectManager, "areaappeand");

        dataSheet.prependDataInTextArea(objectManager, "areaappeandPrepend");


        browser.sleep(10000).then(function () {
            console.log("Wait for some time here");
        })

        //     dataSheet.clearTextArea(objectManager, "area");

        //    dataSheet.clearTextBox(objectManager, "AnalysisID");

        // searchManager.gloablSearchWithFilter("equipment"," ~  ~ QA TM V351","Equipment","Equipment","Functional Location");
        // searchManager.gloablSearchWithFilter("equipment"," ~  ~ QA TM V351","Equipment","Equipment","Functional Location");

        // searchManager.globalSearch("reference document", "Test Reference Document", "Reference Document");


        /!*  searchManager.globalSearchOnly("equipment").then(function () {
         console.log("We have searched something");
         });*!/

        //   browser.sleep(10000).then(function () {
        //       console.log("Search operaton is done");
        //   })

        //    navigation.navigateToScreen(Menu.Health, SubMenu.HealthAssetCriticalityAnalysis);

        //  lem.findElement("delete", "newButton").click();


        //   dataSheet.enterDataInTextBox(objectManager, "AnalysisID");
        // dataSheet.enterDataInTextBox(objectManager, "AnalysisDes");


        browser.sleep(10000).then(function () {
            callback();
        })


        //localManager = objectManager.getLocalElementManager("LCC", "common");


        //  dataSheet.clearTextArea("delete");

        //globalManager.findElement("loginMeridium","userName").sendKeys("some of the junk value");

        //localManager.findElement("delete","password").sendKeys("some of the junk value");


    });
};
module.exports = myStepDefinitionsWrapper;*/
