var myStepDefinitionsWrapper = function () {
    this.Given(/^I will login and navigate and then i will create a new analysis$/, function (callback) {
        var myObjManager = objectManager.getLocalElementManager("LCC", "createAnalysis1223", "analysis3333");

        var lem = myObjManager.ElementManager;
        var tem = myObjManager.TestHelper;

        browser.ignoreSynchronization = true;

        login.navigateAndLogin();

        navigation.navigateToScreen(menu.health, subMenu.healthAssetCriticalityAnalysis);
        lem.findElement("createAnalysis1223", "newAnalysis").click().then(function () {
            console.log("I have just clicked new Analysis button");
        });

        dataSheet.enterDataInTextBox(objectManager, "createAnalysis1223", "newAnalysisId");
        dataSheet.enterDataInTextArea(objectManager, "createAnalysis1223","analysisScope");


        lem.findElement("createAnalysis1223", "save").click().then(function () {
            console.log("I have just clicked on Save button");
        });

        searchManager.globalSearch("ABC","ABC");

        myObjManager.currentPage = "demoPart";

        dataSheet.appendDataInTextArea()

        myObjManager = objectManager.getLocalElementManager("LCC", "createAnalysis1223", "demoPart");

        callback();
    });
};
module.exports = myStepDefinitionsWrapper;