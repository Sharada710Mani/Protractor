/**
 * Created by nekumar on 7/26/2017.
 */

(function () {
    'use strict';
    // Expected declaration condition for the wait.
    var eC = protractor.ExpectedConditions;

    var currentPage = 'lccPOLocators';
    var lccPo = function () {

        return {

            verifyHeader: function () {
                console.log("WE are into the validation function");
                var element = cem.findElement("lccPOLocators", "newAnalysis");

                return browser.wait(eC.visibilityOf(element), 12000).then(function () {
                    console.log("Polling the dom");
                    return TestHelper.elementToBeClickable("lccPOLocators", "newAnalysis").then(function(){
                        return TestHelper.titleContains("sddssd");

                    });
                });


                // var textHeader = cem.findElement(currentPage, "header");

                // TestHelper.elementIsVisible(currentPage, "header");

                // var text = textHeader.getText().then(function (textToValidate) {
                //TestHelper.t(textHeader.getText(),"Life Cycle Cost Analysis Overvie");

                //console.log("WE have done the validation");

                //     });


            },

            setPassword: function (password) {
                return cem.findElement(currentPage, 'password').sendKeys(password);
            },

        }
    };

    module.exports = new lccPo();

}());
