/**
 * Created by nekumar on 7/27/2017.
 */

(function () {
    'use strict';
    var currentPage = 'myHomePage';
    var LandingPagePO = function () {

        return {
            goToLCC: function () {
                cem.findElement("myHomePage", "strat").click().then(function () {
                    cem.findElement("myHomePage", "lcc").click();
                });
            }
        }
    };

    module.exports = new LandingPagePO();

}());
