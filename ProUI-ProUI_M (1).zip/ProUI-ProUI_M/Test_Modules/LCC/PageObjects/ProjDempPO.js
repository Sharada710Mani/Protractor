/**
 * Created by nekumar on 7/28/2017.
 */

(function () {
    'use strict';
    // Expected declaration condition for the wait.
    var EC = protractor.ExpectedConditions;

    var currentPage = 'lccPOLocators';
    var ProjDemoPO = function () {

        return {

            goToLCCPage: function(){
              cem.findElement("myHomePage","strat").click().then(function(){
                  cem.findElement("myHomePage","lcc").click();
              })
            },


            newAnalysis: function () {
                var newAnalysisElement = cem.findElement("lccPOLocators", "newAnalysis");

                // return browser.wait(EC.)
                return browser.wait(EC.visibilityOf(newAnalysisElement), 12000).then(function () {
                    return TestHelper.elementToBeClickable(currentPage, "newAnalysis");
                });
            },

            validateAnalylsis: function () {
                return TestHelper.isElementPresent(currentPage, "newAnalysisBtn");
            },
        }
    };

    module.exports = new ProjDemoPO();

}());

