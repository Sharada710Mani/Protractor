/**
 * Created by nekumar on 8/28/2017.
 */


// var firstValue= dataFile.lcc.locatorType;

/*
var readData = function() {
    var dataFile = require("../../LCC/TestData/HomePage.json");
this.readData = function(pageName, keyValue) {
    var n = dataFile[pageName][keyValue],
        locType = n.locatorType,
        locValue = n.locatorValue,
        locData = n.locatorData;

    console.log("The value of loc type is: " + locType +   "   " +  locValue + "   " + locData);
        }


};
module.exports = new readData();
*/


