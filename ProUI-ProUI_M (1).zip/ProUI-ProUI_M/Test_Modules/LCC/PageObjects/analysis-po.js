function Analysis() {
    var self=this;
    var eleManager = objectManager.getLocalObjectManager("LCC", "demoPart");
    var lem = eleManager.ElementManager;

    this.clickNewAnalysis = function () {
        return lem.findElement("demoPart", "newAnalysis").click();
    }

    this.enterAnalysisId = function (analysisId) {
        return dataSheet.enterDataInTextBox(eleManager, "newAnalysisId", analysisId)
    }

    this.enterAnalysisDescription = function (description) {
        return dataSheet.enterDataInTextArea(eleManager, "scope", description);
    }

    this.save = function () {
        return lem.findElement("demoPart", "save").click();
    }

    this.enterAndSaveAalysis = function (analysisId, description) {
        return  self.clickNewAnalysis().then(function(){
            return self.enterAnalysisId(analysisId).then(function () {
                return self.enterAnalysisDescription(description).then(function () {
                    return self.save();
                })
            })
        })
    }
}
module.exports = Analysis;
