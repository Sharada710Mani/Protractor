(function () {
    'use strict';
    var currentPage = 'createAnalysis';
    var homePage = function () {

        return {

            navigateToLCC: function () {

                cem.findElement(currentPage,'strategy').click();
                browser.sleep(50000000);
                browser.driver.sleep(50000000);
                setTimeout(function(){},5000);
                return cem.findElement(currentPage,'lcc').click();

            },


        }
    };

    module.exports = new homePage();

}());

