/**
 * Created by nekumar on 7/28/2017.
 */
(function () {
    'use strict';
    // Expected declaration condition for the wait.
    var EC = protractor.ExpectedConditions;

    var currentPage = 'myHomePage';
    var tempPo = function () {

        return {

            goToLCC: function () {
                cem.findElement(currentPage, "strat").click().then(function () {
                    cem.findElement(currentPage, "lcc").click().then(function () {
                        console.log("we are on the landing page");
                    })
                });


                /* var newAnalysisElement = cem.findElement(currentPage, "newAnalysis");
                 return browser.wait(EC.visibilityOf(newAnalysisElement), 12000).then(function () {
                 return TestHelper.elementToBeClickable(currentPage, "newAnalysis");
                 });
                 */
            },
            clickNewAnalysis: function () {

                return TestHelper.elementToBeClickable("lccPOLocators","newAnalysis").click();

                // return TestHelper.isElementPresent(currentPage, "newAnalysisBtn");
            },
        }
    };

    module.exports = new tempPo();

}());

