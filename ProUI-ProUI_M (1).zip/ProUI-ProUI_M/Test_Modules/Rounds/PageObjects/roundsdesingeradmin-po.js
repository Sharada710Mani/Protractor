/**
 * Created by Sathya.Kunda on 01/17/2018.
 *  * */
'use strict';
var currentPage = 'rdadminobj';
var RoundsDesignerAdminPage = function () {
    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var rdAdminObjectManager = objectManager.getLocalObjectManager("Rounds", "roundsdesigner", currentPage);
    var lubPriElementManager = rdAdminObjectManager.ElementManager;
    var ObjTestHelper = objManager.TestHelper;
    var EC = protractor.ExpectedConditions;
    var promiseUtilFile = require('../../../Common_Template/PageObjects/promise-utils-po.js');
    var promiseUtil = new promiseUtilFile();
   
    this.navigateToRoundsDesigner = function () {
        promiseUtil.getDisplayedElement(lubPriElementManager.findElement(currentPage, "lnkRoundsDesigner")).then(
            function(lnkRoundsDesigner){
                lnkRoundsDesigner.getText().then(function(t){console.log(t)})
                console.log("Assertion to check the Rounds desinger link is displayed on Admin page");
           //    ObjTestHelper.assertEqual(lnkRoundsDesigner.getText(), 'Rounds Designer');
               // TestHelper.assertEqual(pageTitle.getText(), 'Lubrication Priority Mapping');
                 lnkRoundsDesigner.click();
            }
        )
    };

    /**
     * This function will validate Rounds Designer link on Admin page     
     */
  

    /**
 * This function will validate Compliance link on Rounds Desinger page    
 */
    this.lnkcompliance = function () {
        return ObjTestHelper.isElementPresent(currentPage, "lnkcompliance").then(function (displayed) {
            expect(displayed).to.equal(true);

            // Explicit wait for the element to check the Compliance link 
            var waitlnkCompliance = lubPriElementManager.findElement(currentPage, "lnkcompliance");
            promiseUtil.isElementDisplayed(waitlnkcompliance);

            // Validate the Assertion to check the Compliance link is displayed on Admin page
            var chklnkCompliance = lubPriElementManager.findElement(currentPage, "lnkcompliance").getText();
            TestHelper.assertEqual(chklnkCompliance, lnkcompliance);
            console.log("Assertion to check the Compliance link is displayed on Admin page");

        })
    };

    // This method will verify the Assetion of the rounds Desinger link
    this.lnkcompliance = function (lnkcompliance) {
        return ObjTestHelper.isElementPresent(currentPage, "lnkcompliance").then(function (displayed) {
            var msg = lubPriElementManager.findElement(currentPage, "lnkcompliance").getText();
            ObjTestHelper.assertEqual(msg, lnkcompliance);

            // Explicit wait for the element to check the Compliance link 
            var waitlnkCompliance = lubPriElementManager.findElement(currentPage, "lnkcompliance");
            promiseUtil.isElementDisplayed(waitlnkcompliance);

            // Validate the Assertion to check the Compliance link is displayed on Admin page
            var chklnkCompliance = lubPriElementManager.findElement(currentPage, "lnkcompliance").getText();
            TestHelper.assertEqual(chklnkCompliance, lnkcompliance);
            console.log("Assertion to check the Compliance link is displayed on Admin page");

        })
    };

    /**
   * This function will validate Lubrication priority link on Rounds Desinger page    
   */
    this.lnklubricaionpriority = function () {
        return ObjTestHelper.isElementPresent(currentPage, "lnklubricaionpriority").then(function (displayed) {
            expect(displayed).to.equal(true);

            // Explicit wait for the element to check the Lubrication Priority link 
            var waitlnkLubPri = lubPriElementManager.findElement(currentPage, "lnklubricaionpriority");
            promiseUtil.isElementDisplayed(waitlnkLubPri);

            // Validate the Assertion to check the Lubrication Priority link is displayed on Admin page
            var chklnkLubPri = lubPriElementManager.findElement(currentPage, "lnklubricaionpriority").getText();
            TestHelper.assertEqual(chklnkLubPri, lnklubricaionpriority);
            console.log("Assertion to check the Lubrication Priority is displayed on Admin page");
        })
    };


    /**
  * This function will validate Route Sequence on Rounds Desinger page    
  */
    this.lnkrouteSequence = function () {
        return ObjTestHelper.isElementPresent(currentPage, "lnkrouteSequence").then(function (displayed) {
            expect(displayed).to.equal(true);

            // Explicit wait for the element to check the Rounds Sequence link 
            var waitlnkRequenceSeq = lubPriElementManager.findElement(currentPage, "lnklubricaionpriority");
            promiseUtil.isElementDisplayed(waitlnkLubPri);

            // Validate the Assertion to check the Lubrication Priority link is displayed on Admin page
            var chklnkLubPri = lubPriElementManager.findElement(currentPage, "lnklubricaionpriority").getText();
            TestHelper.assertEqual(chklnkLubPri, lnklubricaionpriority);
            console.log("Assertion to check the Lubrication Priority is displayed on Admin page");
        })
    };


    /**
    * This function will validate Default Device Settings on Rounds Desinger page    
    */
    this.lnkdefaultdevicesettings = function () {
        return ObjTestHelper.isElementPresent(currentPage, "lnkdefaultdevicesettings").then(function (displayed) {
            expect(displayed).to.equal(true);
            
            // Explicit wait for the element to check the Default Device Settings link 
            var waitlnkdevset = lubPriElementManager.findElement(currentPage, "lnkdefaultdevicesettings");
            promiseUtil.isElementDisplayed(waitlnkdevset);

            // Validate the Assertion to check the default device settings link is displayed on Admin page
            var chklnkdevse = lubPriElementManager.findElement(currentPage, "lnkdefaultdevicesettings").getText();
            TestHelper.assertEqual(chklnkdevse, lnkdefaultdevicesettings);
            console.log("Assertion to check the default device setting is displayed on Admin page");
        })
    };

    /**
    * This function will validate Rounds Default Settings on Rounds Desinger page    
    */
    this.lnkroundsdefaultSettings = function () {
        return ObjTestHelper.isElementPresent(currentPage, "lnkroundsdefaultSettings=").then(function (displayed) {
            expect(displayed).to.equal(true);
               // Explicit wait for the element to check the Rounds Default Settings link 
               var waitlnkroundsdefault = lubPriElementManager.findElement(currentPage, "lnkroundsdefaultSettings");
               promiseUtil.isElementDisplayed(waitlnkroundsdefault);
   
               // Validate the Assertion to check the Rounds default settings link is displayed on Admin page
               var chklnkdevse = lubPriElementManager.findElement(currentPage, "lnkdefaultdevicesettings").getText();
               TestHelper.assertEqual(chklnkdevse, lnkdefaultdevicesettings);
               console.log("Assertion to check the Rounds default setting is displayed on Admin page");
           })
      
    };

};
module.exports = new RoundsDesignerAdminPage();
