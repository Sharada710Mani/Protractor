/**
 * Created by Sathya.Kunda on 01/17/2018.
 *  * */
'use strict';
var lubricationPriorityPage = function () {
    var currentPage = 'lubricationpriority';

    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var lubPriObjectManager = objectManager.getLocalObjectManager("Rounds", "lubricationpriority", currentPage);
    var lubPriElementManager = lubPriObjectManager.ElementManager;
    var ObjTestHelper = lubPriObjectManager.TestHelper;
    var promiseUtilFile = require('../../../Common_Template/PageObjects/promise-utils-po.js');
    var promiseUtil = new promiseUtilFile();

    /**
   * This function will validate Red Color lubriction priority field on Lubrication Priority Mapping page 
   */
    this.getLubricationRedPriorityDDL = function () {
        return promiseUtil.getDisplayedElement(lubPriElementManager.findElement(currentPage, "selectRedValue")).then(function (ddlRed) {
            var lubricationRedPriorityDDL = new apmSelectFile(ddlRed);
            return lubricationRedPriorityDDL;
        });
    };

    /**
    * This function will validate Orange Color lubriction priority field on Lubrication Priority Mapping page 
    */
    this.getLubricationOrangePriority = function () {
        return promiseUtil.getDisplayedElement(lubPriElementManager.findElement(currentPage, "selectOrangeValue")).then(function (ddlOrange) {
            var lubricationOrangePriorityDDL = new apmSelectFile(ddlOrange);
            return lubricationOrangePriorityDDL;
        });
    };


    /**
    * This function will validate Yellow Color lubriction priority field on Lubrication Priority Mapping page 
     */
    this.getLubricationYellowPriority = function () {
        return promiseUtil.getDisplayedElement(lubPriElementManager.findElement(currentPage, "selectYellowValue")).then(function (ddlYellow) {
            var lubricationYellowPriorityDDL = new apmSelectFile(ddlYellow);
            return lubricationYellowPriorityDDL;
        });
    };

    // Validate Lubrication Priority Mapping title
    this.verifyLubricationTitle = function () {
        return promiseUtil.getDisplayedElement(lubPriElementManager.findElement(currentPage, "lubricationPageTitle")).then(function (pageTitle) {
            ObjTestHelper.assertEqual(pageTitle.getText(), 'Lubrication Priority Mapping');
            console.log("Validate Lubrication Priority Mapping header title");
            return true;
        });

    };
};
module.exports = new lubricationPriorityPage();