var myStepDefinitionsWrapper = function () {

    var lubricationObjectManager = objectManager.getLocalObjectManager("Rounds", "lubricationpriority", "lubricationpriority");
    var lem = lubricationObjectManager.ElementManager;
    var ObjTestHelper = lubricationObjectManager.TestHelper;

    var currentPage = "lubricationpriority";
    var promiseUtilFile = require('../../../Common_Template/PageObjects/promise-utils-po.js');
    var promiseUtil = new promiseUtilFile();

    this.Given(/^login to the application$/, function (callback) {

        browser.ignoreSynchronization = true;
        login.navigateAndLogin().then(function () {
            callback();
        });
    });

    this.When(/^navigate to Admin page of the Application Settings$/, function (callback) {
        navigation.navigateToScreen(menu.admin, subMenu.adminApplicationSettings).then(function () {
            console.log("Admin page of teh application settings page is displayed");
            callback();
        });
    });

    this.Then(/^navigate to Lubrication Priority Mapping page$/, function (callback) {
        roundsDesignerAdmin.navigateToRoundsDesigner();
        promiseUtil.click(lem.findElement(currentPage, "lnklubricaionpriority")).then(
            function () {
                lubricationPage.verifyLubricationTitle();
                callback();
            }
        )
    });

    this.Then(/^select the Lubricaiton values$/, function (callback) {
        lubricationPage.getLubricationRedPriorityDDL().then(function (ddlRed) {
            ddlRed.selectByText('High');
            ddlRed.close();
        });

        lubricationPage.getLubricationOrangePriority().then(function (ddlOrange) {
            ddlOrange.selectByText('High');
            ddlOrange.close();
        });

        lubricationPage.getLubricationYellowPriority().then(function (ddlYellow) {
            ddlYellow.selectByText('High');
            ddlYellow.close();
            callback();
        });
    });

    this.Then(/^save the record$/, function (callback) {
        promiseUtil.click(lem.findElement(currentPage, "btnSave")).then(
            function () {
                console.log('Verify saved details.');
                lubricationPage.getLubricationRedPriorityDDL().then(function (ddlRed) {
                    ObjTestHelper.assertEqual(ddlRed.getSelectedOptionText(), 'High');
                });
                lubricationPage.getLubricationOrangePriority().then(function (ddlOrange) {
                    ObjTestHelper.assertEqual(ddlOrange.getSelectedOptionText(), 'High');
                });
                lubricationPage.getLubricationYellowPriority().then(function (ddlYellow) {
                    ObjTestHelper.assertEqual(ddlYellow.getSelectedOptionText(), 'High');
                });

                //Verify success message
                promiseUtil.getDisplayedElement(lem.findElement(currentPage, "saveToaster")).then(function (success) {
                    ObjTestHelper.assertEqual(success.getText(), 'Mappings saved successfully');
                });

                callback();
            }
        );
    });
};
module.exports = myStepDefinitionsWrapper;