

    RiskCategoryType = {

        Safety: "Safety",
        Environment: "Environment",
        Operations: "Operations",
        Financial: "Financial",
        Health: "Health"
    },
    RiskAssessmentType = {
        MitigatedRisk : "MitigatedRisk",
        UnMitigatedRisk : "UnMitigatedRisk"
    },
    FinancialRiskCategoryType = {
        ProductionLoss : "Production Loss",
        MaintenanceCost : "Maintanance Cost",
        Consequence : "Consequence",
        FinancialRisk : "Financial Risk"
    },
    ProbabilityType = {
        Frequent : "Frequent",
        Probable : "Probable",
        Possible : "Possible",
        Remote : "Remote",
        Improbable : "Improbable"
    }
