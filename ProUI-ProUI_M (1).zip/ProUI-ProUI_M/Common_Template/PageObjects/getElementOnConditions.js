/**
 * Created by nekumar on 9/11/2017.
 */

// Deign this class to get inherited wherever element is required!!!!
var getElement = function () {
    var EC = protractor.ExpectedConditions;
    var timeWait = 0;

    this.elementIsDisplayed = function (locatorType, locatorValue, oTimeInMillliSec) {
        if (oTimeInMillliSec === undefined || parseInt(oTimeInMillliSec) <= 0) {
            timeWait = 10000;
        }
        else {
            timeWait = oTimeInMillliSec;
        }

        if ((locatorType.trim()).toLowerCase() === "xpath") {
            return browser.wait(function () {
                return browser.driver.findElement(by.xpath(locatorValue)).isDisplayed();
            }, timeWait, "Time is out so we are failing this @!@!@@!@");
        }

    };

    this.getElementAfterDisplay = function (locatorType, locatorValue, oTimeInMillliSec) {
        if (this.elementIsDisplayed(locatorType, locatorValue, oTimeInMillliSec)) {
            return browser.driver.findElement(by.xpath(locatorValue));
        }
        else {
            console.log("Element not found!!!");
            return null;
        }


        /*  this.elementIsDisplayed(locatorType, locatorValue, oTimeInMillliSec).then(null,function(){
         console.log("Element not found with the given locatorValue");
         })*/


        /*  this.elementIsDisplayed(locatorType, locatorValue, oTimeInMillliSec).then(function(element){
         console.log("We are sucessful");
         },function(){
         console.log("We are failure");
         })*/


        /*{
         return browser.driver.findElement(by.xpath(locatorValue));
         }
         else{
         console.log("Element not found with the given locatorValue");
         }*/
    }
};

module.exports = getElement;