function Tabs() {
    var self = this;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    var EC = protractor.ExpectedConditions;

    this.getAllTabs = function () {
        var locator = by.xpath("//div[@class='top-nav-main-tabs-group']//li");
        return promiseUtil.getAll(locator);
    }

    this.getAllTabsText = function () {
        var locator = by.xpath("//div[@class='top-nav-main-tabs-group']//li");
        return promiseUtil.getAllText(locator);
    }

    this.closeAllTabs = function (timeout) {
        var deferred = protractor.promise.defer();
        var tabLocator = by.xpath("//div[@class='top-nav-main-tabs-group']//i[@class='tab-close ds ds-cross']");
        var currentTab = element(by.xpath("//div[@class='top-nav-main-tabs-group']//i[@class='tab-close ds ds-cross'][1]"));
        promiseUtil.getAll(tabLocator).then(function (tabs) {
            for (var i = 0; i < tabs.length; i++) {
                promiseUtil.click(currentTab)
                    browser.sleep(timeout);
            }
            return true;
        }).then(function (status) {
            deferred.fulfill(status);
        });

        return deferred.promise;
    }

    this.getTabs = function (tabText) {
        var locator = "//div[@class='top-nav-main-tabs-group']//li[@title='" + tabText + "']";
        return promiseUtil.getAll(by.xpath(locator));
    }

    this.getCurrentTab = function () {
        var tab = element(by.xpath("//div[@class='top-nav-main-tabs-group']//li[@class='test-border short-border active']"));
        return promiseUtil.getDisplayedElement(tab);
    }

    this.getCurrentTabText = function () {
        return self.getCurrentTab().then(function (tab) {
            return tab.getAttribute('title').then(function (text) {
                return text;
            })
        })
    }

    this.selectTab = function (tabText, timeout) {
        timeout = timeout || 3000;
        var tab = element(by.xpath("(//div[@class='top-nav-main-tabs-group']//li[@title='" + tabText + "'])[1]"));
        return promiseUtil.click(tab).then(function () {
            browser.sleep(timeout);
            return true;
        })
    }

    this.closeTab = function (tabText, timeout) {
        timeout = timeout || 3000;
        var tab = element(by.xpath("(//div[@class='top-nav-main-tabs-group']//li[@title='" + tabText + "']//i[@class='tab-close ds ds-cross'])[1]"));
        return promiseUtil.click(tab).then(function () {
            browser.sleep(timeout);
            return true;
        })
    }

    this.closeCurrentTab = function (timeout) {
        timeout = timeout || 3000;
        var tab = element(by.xpath("//div[@class='top-nav-main-tabs-group']//li[@class='test-border short-border active']//i[@class='tab-close ds ds-cross']"));
        return promiseUtil.click(tab).then(function () {
            browser.sleep(timeout);
            return true;
        })
    }
}
module.exports = Tabs;

