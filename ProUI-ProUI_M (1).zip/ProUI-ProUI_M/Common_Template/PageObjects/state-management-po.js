function StateManagement() {
    'use strict';
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();

    this.getCurrentState = function () {
        var element = element(by.css("span[data-bind='text: activeState']"));
        return promiseUtil.getDisplayedElementText(element);
    };

    this.openStatePopup = function () {
        var stateOpener = element(by.css("button[data-bind*='click: togglePopover']"));
        var statePopup = element(by.xpath("//div[@class='mi-state popover fade bottom in']"));
        return promiseUtil.clickAndVerifyDisplayedElement(stateOpener,statePopup);
    };

    this.clickOnStateButton = function (stateButtonText) {
        var stateButton = element(by.xpath("//div[@class='mi-state popover fade bottom in']//*[text()='" + stateButtonText + "']"));
        return promiseUtil.click(stateButton);
    };

    this.fillStateAssignment = function (state, userName) {
        var deferred = protractor.promise.defer();

        var stateDropdown = element(by.xpath("//td[text()='" + state + "']/parent::tr//select//option[text()='" + userName + "']"));
        promiseUtil.isElementPresent(stateDropdown).then(function () {
            promiseUtil.click(stateDropdown).then(function (clicked) {
                deferred.fulfill(clicked);
            });
        });
        return deferred.promise;
    };

    this.fillAllStateAssignment = function (userName) {
        var deferred = protractor.promise.defer();

        //Active Dropdown
        this.fillStateAssignment('Active', userName);

        //Complete Dropdown
        this.fillStateAssignment('Complete', userName);

        //Pending Approval Dropdown
        this.fillStateAssignment('Pending Approval', userName);

        //Planning Dropdown
        this.fillStateAssignment('Planning', userName);

        //Review Dropdown
        this.fillStateAssignment('Review', userName);

        deferred.fulfill(true);
        return deferred.promise;
    };

    this.saveStateAssignment = function () {
        var deferred = protractor.promise.defer();

        var doneButton = element(by.xpath("//div[@class='dialog-wrapper']//button[text()='Done']"));
        promiseUtil.isElementDisplayed(doneButton).then(function () {
            promiseUtil.click(doneButton).then(function (clicked) {
                deferred.fulfill(clicked);
            });
        });

        return deferred.promise;
    };

    this.fillAndSaveAllStateAssignment = function (userName) {
        var deferred = protractor.promise.defer();

        this.fillAllStateAssignment(userName).then(function () {
            self.saveStateAssignment().then(function (result) {
                deferred.fulfill(result);
            });
        });

        return deferred.promise;
    };

    this.cancelStateAssignment = function () {
        var deferred = protractor.promise.defer();

        var cancelButton = element(by.xpath("//div[@class='dialog-wrapper']//button[text()='Cancel']"));
        promiseUtil.isElementDisplayed(cancelButton).then(function () {
            promiseUtil.click(cancelButton).then(function (clicked) {
                deferred.fulfill(clicked);
            });
        });

        return deferred.promise;
    };

    this.selectStateAssignmentTab = function (tabText) {
        var deferred = protractor.promise.defer();

        var tab = element(by.xpath("//ul[@class='state-assignment-tabs nav nav-tabs']//a[text()='" + tabText + "']"));
        promiseUtil.isElementDisplayed(tab).then(function () {
            promiseUtil.click(tab).then(function () {
                var selectedTab = element(by.xpath("//ul[@class='state-assignment-tabs nav nav-tabs']//li[@class='active']//a[text()='" + tabText + "']"));
                promiseUtil.isElementDisplayed(selectedTab).then(function (displayed) {
                    deferred.fulfill(displayed);
                });
            });
        });

        return deferred.promise;
    };
}
module.exports = StateManagement;

