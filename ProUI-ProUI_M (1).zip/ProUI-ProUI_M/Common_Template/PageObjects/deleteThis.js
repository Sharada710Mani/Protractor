function deleteMe(){
    var deletekeyword ="Value to be deleted";
};