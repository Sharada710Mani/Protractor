/**
* Created by nekumar on 9/6/2017.
*/
var searchManager = function () {
    'use strict';
    var self = this;
    var currentPage = "globalSearch";
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    var objectManagerFile = require('ProUI-Utils').ObjectManager;
    var objectManager = new objectManagerFile();
    var searchObjectManager = objectManager.getGlobalObjectManager(currentPage);
    var searchElementManager = searchObjectManager.ElementManager;

    /**
     * Global Search Only: This function will click on global search and then it will enter the search value.
     * This is not going to click any of the filtered record.
     * @param valueToSearch : Provide the value to be searched in global search!
     * @returns {*}
     */
    this.globalSearchOnly = function (valueToSearch) {
        var deferred = protractor.promise.defer();

        promiseUtil.click(searchElementManager.findElement(currentPage, "searchIcon"));
        promiseUtil.sendKeys(searchElementManager.findElement(currentPage, "searchInput"), valueToSearch);
        promiseUtil.click(searchElementManager.findElement(currentPage, "innerSearchIcon")).then(function (result) {
            console.log("Entered search value in global search: " + valueToSearch + " and clicked on Search Icon!");
            deferred.fulfill(result);
        });

        return deferred.promise;
    };

    /**
     * Gloabl Search: This function will search the record based on value provided.
     * This will open the first record after search based on record link name and description provided.
     * @param valueToSearch : Provide the value to be entered in the gloabl search text box.
     * @param recordLinkName : Provide the name of the record to be selected after the search operation!
     * @param oRecordLinkDescription : Optional parameter : Provide the searched record description
     * to be clicked after the search operation!
     * @returns {*}
     */
    this.globalSearch = function (valueToSearch, recordLinkName, oRecordLinkDescription) {
        var deferred = protractor.promise.defer();

        var xpathDynamic = "";
        if (oRecordLinkDescription === undefined || oRecordLinkDescription.trim() == "") {

            xpathDynamic = "//div[@class='result block']//a[text()='" + recordLinkName + "'][1]";
        }
        else {
            xpathDynamic = "(//a[text()='" + recordLinkName + "']/parent::h4/parent::div[@class='result block']//span[text()='" + oRecordLinkDescription + "']//parent::div[@class='result block']//a[text()='" + recordLinkName + "'])[1]";
        }

        self.globalSearchOnly(valueToSearch);

        promiseUtil.click(element(by.xpath(xpathDynamic))).then(function (result) {
            if (result)
                console.log("Clicked on the first element appeared in the result as per criteria");
            else
                console.log("Element not found!!");

            deferred.fulfill(result);
        });

        return deferred.promise;
    };

    this.globalSearchWithFilter = function (valueToSearch, recordLinkName, oRecordLinkDescription, allFamilyValue, oLinkedToValue) {
        var deferred = protractor.promise.defer();

        var xpathDynamic = "";
        var xpathDynamicAllFamilies = "";
        var xpathDynamicLinkedTo = "";
        var emptyTextboxElement = "//input[@title='']";

        if (oRecordLinkDescription === undefined || oRecordLinkDescription.trim() == "") {
            xpathDynamic = "(//div[@class='result block']//a[text()='" + recordLinkName + "'])[1]";
        }
        else {
            xpathDynamic = "//a[contains(text(),'" + recordLinkName + "')]/parent::h4/parent::div[@class='result block']//span[text()='" + oRecordLinkDescription
                + "']//ancestor::ul[@class='list-group']//a[contains(text(),'" + recordLinkName + "')]";
        }

        if (allFamilyValue === undefined || allFamilyValue.trim() === "") {
            console.log("The value of allFamilyValue parameter is either undefined or blank");
        }
        else {
            xpathDynamicAllFamilies = "//p[text()='" + allFamilyValue + "']";
        }

        if (oLinkedToValue) {
            xpathDynamicLinkedTo = "//p[text()='Linked to']/..//p[text()='" + oLinkedToValue + "']";
        }
        self.globalSearchOnly(valueToSearch);
        promiseUtil.click(searchElementManager.findElement(currentPage, "filterDropdown"));
        promiseUtil.click(searchElementManager.findElement(currentPage, "filter"));
        promiseUtil.clear(searchElementManager.findElement(currentPage, "allFamiliesText"));
        promiseUtil.getPresentElement(element(by.xpath(emptyTextboxElement))).then(function () {
            promiseUtil.sendKeys(searchElementManager.findElement(currentPage, "allFamiliesText"), allFamilyValue);
            promiseUtil.click(element(by.xpath(xpathDynamicAllFamilies))).then(function () {
                if (oLinkedToValue) {
                    clearLinkedToTextBox();
                    promiseUtil.sendKeys(searchElementManager.findElement(currentPage, "linkedToDropText"), oLinkedToValue);
                    promiseUtil.getDisplayedElement(element(by.xpath(xpathDynamicLinkedTo))).then(function (ele) {
                        ele.click();
                        promiseUtil.getDisplayedElement(element(by.xpath(xpathDynamic))).then(function (ele2) {
                            ele2.click().then(function () {
                                deferred.fulfill(true);
                            });
                        });
                    });
                }
                else {
                    promiseUtil.click(searchElementManager.findElement(currentPage, "lnkFrstFilteredSearch")).then(
                        function () {
                            console.log("Clicked on the first element appeared in the result as per criteria");
                            deferred.fulfill(true);
                        });
                }
            });
        });
        return deferred.promise;
    };

    var clearLinkedToTextBox = function () {
        var deferred = protractor.promise.defer();

        var elementLinkedTo = element(by.xpath("//input[@title='Linked to']"));
        promiseUtil.getPresentElement(elementLinkedTo).then(function () {
            promiseUtil.getDisplayedElement(searchElementManager.findElement(currentPage, "linkedToDropText")).then(function (linkedElement) {
                linkedElement.clear();
                linkedElement.click().then(function (result) {
                    deferred.fulfill(result);
                });
            });
        });

        return deferred.promise;
    };
};

module.exports = searchManager;

