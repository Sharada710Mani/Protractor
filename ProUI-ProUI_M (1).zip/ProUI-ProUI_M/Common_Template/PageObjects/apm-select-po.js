/**
 * Created by 212588212 on 11/6/2017.
 */

function CustomAPMSelectWrapper(apmSelectElement) {
    var self = this;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    this.xpathForAllOptions = "//div[contains(@style,'visibility: visible')]//div[@data-bind='visible:isOpen(),event:{mousedown:$root.handleMouseDown}']//p[@data-index]";
    this.xpathForAllSelectedOptions = self.xpathForAllOptions + "[contains(@class,'mi-select-option active')]";

    if (arguments.length == 0)
    this.apmSelect = element(by.xpath("(//mi-select)[1]"));
      else
    this.apmSelect = apmSelectElement;

    this.open = function () {
        var deferred = protractor.promise.defer();

       promiseUtil.click(self.apmSelect).then(function(result){
            browser.sleep(3000);
        })
        deferred.fulfill(true);

        return deferred.promise;
    }

    this.close = function () {
        var deferred = protractor.promise.defer();
        self.isMultiple().then(function (multiple) {
            if (multiple)
                browser.actions().click(self.apmSelect.element(by.tagName('i'))).perform();
            browser.sleep(3000);
        })
        deferred.fulfill(true);
        return deferred.promise;
    }

    this.getSelectedOptionText = function () {
        var input = self.apmSelect.element(by.tagName('input'));
        return input.getAttribute('title')
            .then(function (text) {
                return self.isMultiple().then(function (multiple) {
                    if (multiple)
                        return text.split('|')[0];
                    else
                        return text;
                })
            });
    }

    this.getSelectedOption = function () {
        return self.getAllSelectedOptions().then(function (selectedOptions) {
            return selectedOptions[0];
        })
    }

    this.selectByPartialText = function (partialText) {
        return self.open().then(function () {
            var item = element(by.xpath(self.xpathForAllOptions + "[contains(text(),'" + partialText + "')][1]"))
            return  promiseUtil.click(item).then(function () {
                return self.close();
            })
        })
    }

    this.selectByText = function (text) {
        return self.open().then(function () {
            var item = element(by.xpath(self.xpathForAllOptions + "[text()='" + text + "'][1]"))
            return promiseUtil.click(item).then(function () {
                return self.close();
            })
        })
    }

    this.getAllSelectedOptions = function () {
        var deferred = protractor.promise.defer();
        return self.open().then(function () {
            var items = new Array();
            element.all(by.xpath(self.xpathForAllSelectedOptions)).then(function (options) {
                options.forEach(function (option, index) {
                    items.push(option);
                });
            });
            self.close().then(function () {
                return items;
            }).then(function (data) {
                deferred.fulfill(data);
            })
            return deferred.promise;
        })
    }

    this.getAllSelectedOptionsText = function () {
        var deferred = protractor.promise.defer();
        self.getAllSelectedOptions().then(function (selectedOptions) {
            var items = new Array();
            for (var i = 0; i < selectedOptions.length; i++) {
                selectedOptions[i].getAttribute('innerText').then(function (text) {
                    items.push(text)
                })
            }
            return items;
        }).then(function (data) {
            deferred.fulfill(data);
        })
        return deferred.promise;
    }

    this.getAllOptions = function () {
        var deferred = protractor.promise.defer();
        return self.open().then(function () {
            var items = new Array();
            element.all(by.xpath(self.xpathForAllOptions)).then(function (options) {
                options.forEach(function (option, index) {
                    items.push(option);
                });
            });
            self.close().then(function () {
                return items;
            }).then(function (data) {
                deferred.fulfill(data);
            })
            return deferred.promise;
        })
    }

    this.getAllOptionsText = function () {
        var deferred = protractor.promise.defer();
        self.getAllOptions().then(function (allOptions) {
            var items = new Array();
            for (var i = 0; i < allOptions.length; i++) {
                allOptions[i].getAttribute('innerText').then(function (text) {
                    items.push(text)
                })
            }
            return items;
        }).then(function (data) {
            deferred.fulfill(data);
        })
        return deferred.promise;
    }

    this.getAllCount = function () {
        var deferred = protractor.promise.defer();

        self.getAllOptions().then(function(list){
            deferred.fulfill(list.length);
        })

        return deferred.promise;
    };

    this.getAllSelectedCount = function () {
        var deferred = protractor.promise.defer();

        self.getAllSelectedOptions().then(function(list){
            deferred.fulfill(list.length);
        })

        return deferred.promise;
    };

    this.isMultiple = function () {
        var deferred = protractor.promise.defer();
        self.apmSelect.getAttribute('data-multiple').then(function (attributeValue) {
            return attributeValue;
        }).then(function (data) {
            deferred.fulfill(data);
        })
        return deferred.promise;
    };

    this.selectByIndex = function (index) {
        return self.open().then(function () {
            var item = element(by.xpath(self.xpathForAllOptions + "[" + index + "]"));
            return promiseUtil.click(item).then(function () {
                return self.close();
            })
        })
    };

    this.deselectByText = function (text) {
        return self.open().then(function () {
            return promiseUtil.click(element(by.xpath("//div[contains(@style,'visibility: visible')]//div[@data-bind='visible:isOpen(),event:{mousedown:$root.handleMouseDown}']//p[@class='mi-select-option active' and text()='" + text + "'][1]"))).then(function () {
                return self.close();
            });
        });
    };

    this.deselectByPartialText = function (partialText) {
        return self.open().then(function () {
            return promiseUtil.click(element(by.xpath("//div[contains(@style,'visibility: visible')]//div[@data-bind='visible:isOpen(),event:{mousedown:$root.handleMouseDown}']//p[@class='mi-select-option active' and contains(text(),'" + partialText + "')][1]"))).then(function () {
                return self.close();
            });
        });
    }

    this.deselectByIndex = function (index) {
        return self.open().then(function () {
            return promiseUtil.click(element(by.xpath("//div[contains(@style,'visibility: visible')]//div[@data-bind='visible:isOpen(),event:{mousedown:$root.handleMouseDown}']//p[@class='mi-select-option active'][" + index + "]"))).then(function () {
                return self.close();
            });
        });
    }

    /**
     *
     * @returns {*|promise}
     */
    this.deselectAll = function () {
        var deferred = protractor.promise.defer();
        self.open().then(function () {
            element.all(by.xpath("//div[contains(@style,'visibility: visible')]//div[@data-bind='visible:isOpen(),event:{mousedown:$root.handleMouseDown}']//p[@class='mi-select-option active']")).then(function (options) {
                options.forEach(function (option) {
                    promiseUtil.click(option);
                });
                self.close();
            });
        }).then(function () {
            deferred.fulfill(true);
        })
        return deferred.promise;
    }
};

module.exports = CustomAPMSelectWrapper;


