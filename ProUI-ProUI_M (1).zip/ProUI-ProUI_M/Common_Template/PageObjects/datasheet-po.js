/**
 * Created by nekumar on 8/16/2017.
 */
'use strict';
var xpath = require("../PageObjects/xpathGenerator.js");
var elementFile = require("../PageObjects/getElementOnConditions.js");
var elementManager = new elementFile();
var promiseUtilFile = require('../PageObjects/promise-utils-po.js');
var dateTimePickerFile = require('../PageObjects/datetime-picker-po.js');
var apmSelectFile = require('../PageObjects/apm-select-po.js');
var promiseUtil = new promiseUtilFile();
var dataSheet = function (objectManager) {

    this.objectManager = objectManager;

    /**
     * This will enter the data in the text box based on the Label name defined
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName: Provide the Key Name stored in the JSON data file!
     * @param oDataValue : Optional parameter : If you want to override the data value from json file.
     * @returns {*}
     */
    this.enterDataInTextBox = function (keyName, oDataValue, oIndex) {
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        // Get the labelText and the value to be entered in the text box.
        var labelText = dataValue.labelText;
        var dataToEnter = dataValue.testData;
        if (oDataValue) {
            dataToEnter = oDataValue;
        }

        // Validate if the labelText and data value are correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }
        if (dataToEnter == undefined || !dataToEnter || dataToEnter.trim() === "") {
            console.log("Value of data to enter in the textbox is either undefined or blank: " + dataToEnter);
        }

        var dynamicXpath = this.generateXpath("textbox", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return promiseUtil.click(elementValue).then(function () {
                return promiseUtil.sendKeys(elementValue,dataToEnter).then(function () {
                    console.log("Data value entered in the text box with label: " + labelText + "and value is:" + dataToEnter);
                })
            })
        });
    };

    /**
     * This will enter the data in the text area based on the Label name defined
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName: Provide the Key Name stored in the JSON data file!
     * @param oDataValue : Optional parameter : If you want to override the data value from json file.
     * @returns {*}
     */
    this.enterDataInTextArea = function (keyName, oDataValue, oIndex) {
        // Get the file path
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;
        var dataToEnter = dataValue.testData;
        if (oDataValue) {
            dataToEnter = oDataValue;
        }

        // Validate if the labelText and data value are correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }
        if (dataToEnter == undefined || !dataToEnter || dataToEnter.trim() === "") {
            console.log("Value of data to enter in the textbox is either undefined or blank: " + dataToEnter);
        }

        var dynamicXpath = this.generateXpath("textarea", labelText, oIndex);
        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return promiseUtil.click(elementValue).then(function () {
                return promiseUtil.sendKeys(elementValue,dataToEnter).then(function () {
                    console.log("Data value entered in the text box with label: " + labelText);
                })
            })
        });
    };

    /**
     * Clear existing data from the text box.
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName : Provide the Key Name stored in the JSON data file!
     * @returns {*}
     */
    this.clearTextBox = function (keyName, oIndex) {
        // Get the file path
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;

        // Validate if the labelText is correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }

        var dynamicXpath = this.generateXpath("textbox", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return promiseUtil.click(elementValue).then(function () {
                return promiseUtil.clear(elementValue).then(function () {
                    console.log("Data value is cleared from the text box with label: " + labelText);
                })
            })
        });
    };

    /**
     * Clear existing data from the text area.
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName : Provide the Key Name stored in the JSON data file!
     * @returns {*}
     */
    this.clearTextArea = function (keyName, oIndex) {
        // Get the file path
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;

        // Validate if the labelText is correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }

        var dynamicXpath = this.generateXpath("textarea", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return promiseUtil.click(elementValue).then(function () {
                return promiseUtil.clear(elementValue).then(function () {
                    console.log("Data value is cleared from the text area with label: " + labelText);
                })
            })
        });
    };

    /**
     * This will append the data in the text box based on the Label name defined
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName: Provide the Key Name stored in the JSON data file!
     * @param oDataValue : Optional parameter : If you want to override the data value from json file.
     * @returns {*}
     */
    this.appendDataInTextBox = function (keyName, oDataValue, oIndex) {
        if (!keyName) {
            console.log("Keyname is not correct!");
            return;
        }
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;
        var dataToEnter = dataValue.testData;
        if (oDataValue) {
            dataToEnter = oDataValue;
        }

        // Validate if the labelText and data value are correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }
        if (dataToEnter == undefined || !dataToEnter || dataToEnter.trim() === "") {
            console.log("Value of data to enter in the textbox is either undefined or blank: " + dataToEnter);
        }

        var dynamicXpath = this.generateXpath("textbox", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return elementValue.getAttribute("value").then(function (existingText) {
                return promiseUtil.click(elementValue).then(function () {
                    return promiseUtil.clear(elementValue).then(function () {
                        return promiseUtil.sendKeys(elementValue,existingText + dataToEnter).then(function () {
                            console.log("Data value is appended: " + dataToEnter);
                        })
                    })
                })
            })
        });
    };

    /**
     * This will prepend the data in the text box based on the Label name defined
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName: Provide the Key Name stored in the JSON data file!
     * @param oDataValue : Optional parameter : If you want to override the data value from json file.
     * @returns {*}
     */
    this.prependDataInTextBox = function (keyName, oDataValue, oIndex) {
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;
        var dataToEnter = dataValue.testData;
        if (oDataValue) {
            dataToEnter = oDataValue;
        }

        // Validate if the labelText and data value are correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }
        if (dataToEnter == undefined || !dataToEnter || dataToEnter.trim() === "") {
            console.log("Value of data to enter in the textbox is either undefined or blank: " + dataToEnter);
        }

        var dynamicXpath = this.generateXpath("textbox", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return elementValue.getAttribute("value").then(function (existingText) {
                return promiseUtil.clear(elementValue).then(function () {
                    return promiseUtil.click(elementValue).then(function () {
                        return promiseUtil.sendKeys(elementValue,dataToEnter + existingText).then(function () {
                            console.log("Data value is prepended: " + dataToEnter);
                        })
                    })
                })
            })
        });
    };

    /**
     * This will append the data in the text area based on the Label name defined
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName: Provide the Key Name stored in the JSON data file!
     * @param oDataValue : Optional parameter : If you want to override the data value from json file.
     * @returns {*}
     */
    this.appendDataInTextArea = function (keyName, oDataValue, oIndex) {
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;
        var dataToEnter = dataValue.testData;
        if (oDataValue) {
            dataToEnter = oDataValue;
        }

        // Validate if the labelText and data value are correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }
        if (dataToEnter == undefined || !dataToEnter || dataToEnter.trim() === "") {
            console.log("Value of data to enter in the textbox is either undefined or blank: " + dataToEnter);
        }

        var dynamicXpath = this.generateXpath("textarea", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return elementValue.getAttribute("value").then(function (existingText) {
                return promiseUtil.clear(elementValue).then(function () {
                    return promiseUtil.click(elementValue).then(function () {
                        return promiseUtil.sendKeys(elementValue,existingText + dataToEnter).then(function () {
                            console.log("Data value is appended: " + dataToEnter);
                        })
                    })
                })
            })
        });
    };

    /**
     * This will prepend the data in the text area based on the Label name defined
     * @param objectObjManager : Provide the object manager created in the test case!
     * @param keyName: Provide the Key Name stored in the JSON data file!
     * @param oDataValue : Optional parameter : If you want to override the data value from json file.
     * @returns {*}
     */
    this.prependDataInTextArea = function (keyName, oDataValue, oIndex) {
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var labelText = dataValue.labelText;
        var dataToEnter = dataValue.testData;
        if (oDataValue) {
            dataToEnter = oDataValue;
        }

        // Validate if the labelText and data value are correct.
        if (labelText == undefined || !labelText || labelText.trim() === "") {
            console.log("Value of label text is either undefined or blank: " + labelText);
        }
        if (dataToEnter == undefined || !dataToEnter || dataToEnter.trim() === "") {
            console.log("Value of data to enter in the textbox is either undefined or blank: " + dataToEnter);
        }

        var dynamicXpath = this.generateXpath("textarea", labelText, oIndex);

        return elementManager.getElementAfterDisplay("xpath", dynamicXpath).then(function (elementValue) {
            return elementValue.getAttribute("value").then(function (existingText) {
                return promiseUtil.clear(elementValue).then(function () {
                    return promiseUtil.click(elementValue).then(function () {
                        return promiseUtil.sendKeys(elementValue,dataToEnter + existingText).then(function () {
                            console.log("Data value is prepended: " + dataToEnter);
                        })
                    })
                })
            })
        });
    };

    /**
     * Generate xpath based on element name and label text.
     * @param elementName
     * @param labelText
     * @returns {*}
     */
    this.generateXpath = function (elementName, labelText, index) {
        if (!labelText) {
            console.log("The value of labelText is not defined correctly!!!");
            return;
        }
        if (elementName.trim().toLowerCase() === "textbox") {
            if (index)
                return "((//div[text()='" + labelText + "']/..)//input)[" + index + "]";
            else
                return xpath.forwardSlash + xpath.tagName + xpath.openingBracket +
                    xpath.comparerText + xpath.singleQuote + labelText +
                    xpath.singleQuote + xpath.closingBracket +
                    xpath.forwardSlash + xpath.followingTag + xpath.followedTextTag + xpath.firstArrayElement;
        }
        else if (elementName.trim().toLowerCase() === "textarea") {
            if (index)
                return "((//div[text()='" + labelText + "']/..)//textarea)[" + index + "]";
            else
                return xpath.forwardSlash + xpath.tagName + xpath.openingBracket +
                    xpath.comparerText + xpath.singleQuote + labelText +
                    xpath.singleQuote + xpath.closingBracket +
                    xpath.forwardSlash + xpath.followingTag + xpath.followedTextAreaTag + xpath.firstArrayElement;
        }
        else if (elementName.trim().toLowerCase() === "datetimepicker") {
            if (index)
                return "((//div[text()='" + labelText + "']/..)//mi-date-time)[" + index + "]";
            else
                return "((//div[text()='" + labelText + "']/..)//mi-date-time)[1]";
        }
        else if (elementName.trim().toLowerCase() === "apmselect") {
            if (index)
                return "((//div[text()='" + labelText + "']/..)//mi-select)[" + index + "]";
            else
                return "((//div[text()='" + labelText + "']/..)//mi-select)[1]";
        }
        else {
            console.log("Element name is not correct!");
            return null;
        }
    };

    this.getTextBox = function (keyName, oIndex) {
        var deferred = protractor.promise.defer();
        
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var xpathForTextBox = this.generateXpath("textbox", dataValue.labelText, oIndex);
        var textbox = element(by.xpath(xpathForTextBox));

        deferred.fulfill(textbox);
        return deferred.promise;
    };

    this.getTextArea = function (keyName, oIndex) {
        var deferred = protractor.promise.defer();
        
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var xpathForTextArea = this.generateXpath("textarea", dataValue.labelText, oIndex);
        var textArea = element(by.xpath(xpathForTextArea));

        deferred.fulfill(textArea);
        return deferred.promise;
    };

    this.getDateTimePicker = function (keyName, oIndex) {
        var deferred = protractor.promise.defer();
        
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var xpathForDateTimePicker = this.generateXpath("datetimepicker", dataValue.labelText, oIndex);
        var dateTimePicker = new dateTimePickerFile(element(by.xpath(xpathForDateTimePicker)));

        deferred.fulfill(dateTimePicker);
        return deferred.promise;
    };

    this.getAPMSelect = function (keyName, oIndex) {
        var deferred = protractor.promise.defer();
        
        var dataValue = this.objectManager.readData(this.objectManager.pageName, keyName);
        var xpathForAPMSelect = this.generateXpath("apmselect", dataValue.labelText, oIndex);
        var apmSelect = new apmSelectFile(element(by.xpath(xpathForAPMSelect)));
      
        deferred.fulfill(apmSelect);
        return deferred.promise;
    };

};

module.exports = dataSheet;
