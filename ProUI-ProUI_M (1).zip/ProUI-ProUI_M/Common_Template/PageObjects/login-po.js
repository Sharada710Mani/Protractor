function Login() {
    'use strict';
    var self = this;
    var EC = protractor.ExpectedConditions;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    var currentPage = 'login';

    //Object Manager
    var objectManagerFile = require('ProUI-Utils').ObjectManager;
    var objManager = new objectManagerFile();
    var loginObjectManager = objManager.getGlobalObjectManager(currentPage);
    var loginElementManager = loginObjectManager.ElementManager;

    this.get = function (url) {
        return browser.driver.get(url);
    };

    this.setUserName = function (username) {
        var elementUsername = loginElementManager.findElement(currentPage, 'username');
        return promiseUtil.getDisplayedElement(elementUsername).then(function () {
            return promiseUtil.clear(elementUsername).then(function () {
                return promiseUtil.sendKeys(elementUsername, username).then(function () {
                    return true;
                })
            })
        });
    };

    this.setPassword = function (password) {
        var elementPassword = loginElementManager.findElement(currentPage, 'password');
        return promiseUtil.getDisplayedElement(elementPassword).then(function () {
            return promiseUtil.clear(elementPassword).then(function () {
                return promiseUtil.sendKeys(elementPassword, password).then(function () {
                    return true;
                });
            })
        });
    };

    this.setDatabase = function (database) {
        var ddlDatabase = element(by.xpath("//select//option[text()='" + database + "']"));
        return promiseUtil.getPresentElement(ddlDatabase).then(function () {
            return promiseUtil.click(ddlDatabase).then(function () {
                return true;
            });
        });
    };

    this.clickLoginButton = function () {
        var signinButton = loginElementManager.findElement(currentPage, 'signin');
        var signoutButton = loginElementManager.findElement(currentPage, 'signout');
        return promiseUtil.clickAndVerifyDisplayedElement(signinButton, signoutButton);
    };

    this.signOut = function () {
        var signinButton = loginElementManager.findElement(currentPage, 'signin');
        var signoutButton = loginElementManager.findElement(currentPage, 'signout');
        return promiseUtil.clickAndVerifyDisplayedElement(signoutButton, signinButton);
    };

    this.login = function (userName, password, database) {
        self.setUserName(userName);
        self.setPassword(password);
        if (database) {
            self.setDatabase(database);
        }
        return self.clickLoginButton();
    };

    this.navigateAndLogin = function () {
        var url = browser.params.login.baseUrl;
        var userName = browser.params.login.username;
        var password = browser.params.login.password;
        var database = browser.params.login.database;

        self.get(url);
        return self.login(userName, password, database);
    };
}
module.exports = new Login();

