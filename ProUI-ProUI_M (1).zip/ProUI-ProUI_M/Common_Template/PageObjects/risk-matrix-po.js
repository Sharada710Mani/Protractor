var RiskMatrix = function () {
    'use strict';
    var self= this;

    var RiskMatrixData = require("../TestData/riskMatrix.js");
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js');

    var promiseUtil = new promiseUtilFile();
    var EC = protractor.ExpectedConditions;

    var objManager = require('ProUI-Utils').ObjectManager;
    var objectManager = new objManager();
    var globalObjectManager = objectManager.getGlobalObjectManager("riskMatrix");
    var TestHelper = globalObjectManager.TestHelper;
    var ElementManager = globalObjectManager.ElementManager;

    var IWaitForElementMax = 5000;
    var IWaitForElementMin = 2000;
    var IWaitForSync = 2000;

    /**
     * This will select the Risk Category tab in the risk matrix dialouge box
     * @param RiskCategoryType: Pass the tab Name that needs to be selected
     * @returns {*}
     */
    this.SelectRiskCategory = function (RiskCategoryType) {
        var deferred = protractor.promise.defer();

        var xpathDynamic = element(by.xpath("//a[text()='" + RiskCategoryType + "']"));
        promiseUtil.isElementDisplayed(xpathDynamic).then(function (elementValue) {
            promiseUtil.click(xpathDynamic).then(function (clickedOnTab) {
                console.log("Clicked on the " + RiskCategoryType + "risk category tab");
                deferred.fulfill(clickedOnTab);
            });
            return deferred.promise;
        });
    }
    /**
     * This will return the selected risk category name
     */
    this.getSelectedRiskCategoryName = function () {
        var riskCategoryName ; var deferred = protractor.promise.defer(); var temp;
        var RiskCategoryNamelocator = element(by.xpath("//a[@class='active']/span[@class='risk-rank-tab-title']/parent::a"));
        promiseUtil.getPresentElementText(RiskCategoryNamelocator).then(function (output) {
            temp = output.split(/\s*(?=\d+)/);
            riskCategoryName = temp[0];
            deferred.fulfill(riskCategoryName);
        });

        return deferred.promise;
    };

    /**
     * This will return the selected risk category value
     */
    this.getSelectedRiskCategoryValue = function () {

        var RiskCategoryValuelocator = element(by.xpath("//a[@class='active']/span[@class='risk-rank-tab-title']"));
        return promiseUtil.getPresentElementText(RiskCategoryValuelocator);
    };

    /**
     * This will return an Object of risk category name and value
    */
    this.getSelectedRiskCategoryNameAndValue = function () {
        var deferred = protractor.promise.defer();
        self.getSelectedRiskCategoryName().then(function(categoryName){
            self.getSelectedRiskCategoryValue().then(function(categoryValue){
                deferred.fulfill({riskCategoryName:categoryName,riskCategoryValue:categoryValue});
            })
        });

        return deferred.promise;
    };

    /**
     * Validates Total risk value
     * @param totalRisk: pass total risk to be validated
     * @returns a promise
     */
    this.ValidateTotalRisk = function (totalRisk) {
        return TestHelper.textToBePresentInElement("riskMatrix", "totalRisk", totalRisk);
    };

    /**
     * This will return total risk for a mitigated or unmitigated risk
     */
    this.getTotalRisk = function () {

        var TotalRisklocator = element(by.xpath("//div[@class='total-risk']/span"));
        return promiseUtil.getPresentElementText(TotalRisklocator);
    };

    /**
     * Validates risk category value for a given risk category type
     * @param riskCategoryType : Pass Risk Category Type
     * @param riskValue : Pass Risk value to be validated for the given Risk Category Type
     * @constructor
     */
    this.ValidateRiskCategoryValue = function (riskCategoryType, riskValue) {

        var deferred = protractor.promise.defer();
        var locator = "//li[@title='riskValue']//span";
        var ELocator = by.xpath(locator.replace("riskValue", riskCategoryType));

        browser.wait(EC.textToBePresentInElement(element(ELocator), riskValue), IWaitForElementMin).then(
            function (textPresent) {
                deferred.fulfill(textPresent);
                console.log(riskValue + " is present in  element ");
            });
        return deferred.promise;
    };

    /**
     * This will return risk category value for a given risk category type
     * @param riskCategoryType : Pass the risk Category Type
     */
    this.getRiskCategoryValue = function (riskCategoryType) {

        var locator = "//li[@title='riskValue']//span";
        var ELocator = element(by.xpath(locator.replace("riskValue", riskCategoryType)));

        return promiseUtil.getPresentElementText(ELocator);
    };

    /**
     * Return a row number for a given row Name
     * @param rowName: Pass the row name
     * @returns a promise
     */
    var getRowNumber = function getRowNumber(rowName) {
        var deferred = protractor.promise.defer();
        var i = 0; var arr = {};
        var text = "//tr[@class='risk-matrix-row'][replaceRowNo]//div[@class='header-title']";
        element.all(By.xpath("//tr[@class='risk-matrix-row']//div[@class='header-title']")).then(function (count) {
            for (var j = 1; j <= count.length; j++) {
                var text1 = text.replace("replaceRowNo", j);
                var getRowName = element(By.xpath(text1));
                getRowName.getText().then(function (ou) {
                    i = i + 1;
                    if (ou === rowName) {
                        console.log("required row name found" + rowName);
                        arr[0] = i;
                    }
                })
            }
        }).then(function () {
            deferred.fulfill(arr[0]);
        });
        return deferred.promise;
    };

    /**
     * Return a col number for a given col Name
     * @param colName: Pass the Col name
     * @returns a promise
     */
    var getColNumber = function (colName) {
        var deferred = protractor.promise.defer();
        var i = 0; var arr = {};
        var text = "//tr[@class='risk-matrix-row header']//td[@class='risk-matrix-cell'][replaceColNo]//div[@class='header-title']";
        element.all(By.xpath("//tr[@class='risk-matrix-row header']//div[@class='header-title']")).then(function (count) {
            for (var j = 1; j <= count.length; j++) {
                var text1 = text.replace("replaceColNo", j);
                var ColName = element(By.xpath(text1));
                ColName.getText().then(function (ou) {
                    i = i + 1;
                    if (ou === colName) {
                        console.log("required Column name found" + colName);
                        arr[0] = i;
                    }
                });
            }
        }).then(function () {
            deferred.fulfill(arr[0]);
        });
        return deferred.promise;
    };

    var selectRisk = function (rowName, colName) {

        var deferred = protractor.promise.defer();
        var templocator = "//tr[@class='risk-matrix-row'][replaceRowNo]//td[@name='matrix-cell' and not(@disabled)][replaceColumnNo]";

        getColNumber(colName).then(function (ColNo) {
            var newTemplocator = templocator.replace("replaceColumnNo", ColNo);
            getRowNumber(rowName).then(function (RowNo) {
                var reqLocator = newTemplocator.replace("replaceRowNo", RowNo);
                return browser.wait(EC.presenceOf(element(by.xpath(reqLocator)), 5000)).then(function () {
                    element(by.xpath(reqLocator)).click().then(function (clicked) {
                        deferred.fulfill(clicked);

                        console.log('selected risk based on the given rowname and column name');
                    }),
                        function (Error) {
                            console.log(Error + " Mitigated risk is greater than UnMitigated risk,So Cannot select the given Mitigated risk");

                        }
                        ;
                });
            });
        });
        return deferred.promise;
    };

    /**
     * This will select UnMitigated risk from risk matrix based on the given row and column name
     * @param rowName : Pass the row name
     * @param colName : Pass the column name
     */
    this.selectUnMitigatedRisk = function (rowName, colName) {
        var deferred = protractor.promise.defer();
        selectRisk(rowName, colName).then(function (UnMitigatedRisk) {
            deferred.fulfill(UnMitigatedRisk);
        });
        self.getUnMitigatedRiskValue().then(function (UnMitigatedRiskValue) {
            console.log("Selected UnMitigated risk based on given row and column is " + UnMitigatedRiskValue);
        });
        return deferred.promise;
    };

    /**
     * Validates UmMitigatedRisk risk value for a given risk category
     * @param UmMitigatedRiskValue : pass the Unmitigated risk value that needs to be validated
     */
    this.validateAssignedUmMitigatedRisk = function (UmMitigatedRiskValue) {
        return TestHelper.textToBePresentInElement("riskMatrix", "assignedUmMitigatedRisk", UmMitigatedRiskValue);
    };

    /**
     * This will return Unmitigated risk value from the risk matrix
     */
    this.getUnMitigatedRiskValue = function () {

        var locator = element(by.xpath("//i[@class='icon-riskmatrix-exclamation']/parent::div"));
        return promiseUtil.getPresentElementText(locator);
    };

    /**
     * This will select Mitigated risk from risk matrix based on the given row and column name
     * @param rowName : Pass the row name
     * @param colName : Pass the column name
     */
    this.selectMitigatedRisk = function (rowName, colName) {
        var deferred = protractor.promise.defer();
        selectRisk(rowName, colName).then(function (MitigatedRisk) {
            deferred.fulfill(MitigatedRisk);
        });
        self.getMitigatedRiskValue().then(function (MitigatedRiskValue) {
            console.log("Selected Mitigated risk based on given row and column is " + MitigatedRiskValue);
        });
        return deferred.promise;
    };

    /**
     * Validates MitigatedRiskValue risk value for a given risk category
     * @param MitigatedRiskValue : pass the mitigated risk value that needs to be validated
     */
    this.validatedAssignedMitigatedRisk = function (MitigatedRiskValue) {
        return TestHelper.textToBePresentInElement("riskMatrix", "assignedMitigatedRisk", MitigatedRiskValue);
    };

    /**
     * This will return Mitigated risk value from the risk matrix
     */
    this.getMitigatedRiskValue = function () {

        var locator = element(by.xpath("//i[@class='icon-riskmatrix-tick']/parent::div"));
        return promiseUtil.getPresentElementText(locator);
    };

    /**
     * Financial tab functions
     */
    /**
     * To select Probability type from probability drop down for mitigated and unmitigated risk
     * @param probabilityType : pass the Probability type that needs to be selected from drop down
     * @param RiskAssesmentType : pass for which assessment(Mitigated or UnMitigated) drop down needs to be selected
     * @constructor
     */
    this.SelectProbabilityTypeFromDn = function (probabilityType, RiskAssesmentType) {

        var deferred = protractor.promise.defer();
        var locator;
        if (RiskAssesmentType == RiskAssessmentType.MitigatedRisk) {
            locator = element(by.xpath("//select[@name='mitigated-probability']")).all(by.xpath('//option[@name="' + probabilityType + '"]'));
        }
        if (RiskAssesmentType == RiskAssessmentType.UnMitigatedRisk) {
            locator = element(by.xpath("//select[@name='unmitigated-probability']")).all(by.xpath('//option[@name="' + probabilityType + '"]'));
        }
        locator.click().then(function (dnSelected) {
            deferred.fulfill(dnSelected);
            console.log(probabilityType + " Element present in the drop down");
        });
        return deferred.promise;
    };

    /**
     * To validate Financial Risk Assessment type values
     * @param RiskAssesmentType : pass risk assessment type(Mitigated or UnMitigated)
     * @param FinancialRiskAssessmentType : pass Financial Risk Assessment type(ex: Production Loss,Consequence etc)
     * @param RiskAssessmentValue : pass risk assessment value for a given financial risk assessment type
     */
    this.validateRiskAssessmentInFinancialTab = function (RiskAssesmentType, FinancialRiskAssessmentType, RiskAssessmentValue) {

        var deferred = protractor.promise.defer();
        var xpathDynamic;
        if (RiskAssesmentType == RiskAssessmentType.MitigatedRisk) {
            xpathDynamic = element(by.xpath("//input[@name='mitigated-" + FinancialRiskAssessmentType.replace(" ", "-").toLowerCase() + "' and @value='" + RiskAssessmentValue + "']"));
        }
        if (RiskAssesmentType == RiskAssessmentType.UnMitigatedRisk) {
            xpathDynamic = element(by.xpath("//input[@name='unmitigated-" + FinancialRiskAssessmentType.replace(" ", "-").toLowerCase() + "' and @value='" + RiskAssessmentValue + "']"));
        }
        promiseUtil.isElementDisplayed(xpathDynamic).then(function (elementPresent) {
            deferred.fulfill(elementPresent);
            console.log("Expected " + FinancialRiskAssessmentType + " value is same as actual : " + RiskAssessmentValue);
           
        })
        return deferred.promise;
    };

    /**
     * This will return Financial Risk Assessment Type value for a given Financial Risk Assessment Type
     * @param RiskAssesmentType : Pass risk assessment type(Mitigated or UnMitigated)
     * @param FinancialRiskAssessmentType : Pass Financial Risk Assessment type(ex: Production Loss,Consequence etc)
     */
    this.getRiskAssessmentTypeValueFromFinancialTab = function (RiskAssesmentType, FinancialRiskAssessmentType) {
        var deferred = protractor.promise.defer();
        var xpathDynamic;
        if (RiskAssesmentType == RiskAssessmentType.MitigatedRisk) {
            xpathDynamic = element(by.xpath("//input[@name='mitigated-" + FinancialRiskAssessmentType.replace(" ", "-").toLowerCase()+"']"));
        }
        if (RiskAssesmentType == RiskAssessmentType.UnMitigatedRisk) {
            xpathDynamic = element(by.xpath("//input[@name='unmitigated-" + FinancialRiskAssessmentType.replace(" ", "-").toLowerCase()+"']"));
        }
        promiseUtil.isElementDisplayed(xpathDynamic).then(function () {
            xpathDynamic.getAttribute('value').then(function (text) {
                deferred.fulfill(text);
            })
        })
        return deferred.promise;
    };

    /**
     * This will edit Financial Risk Assessment Type value for a given Financial Risk Assessment Type
     * @param RiskAssesmentType : pass risk assessment type(Mitigated or UnMitigated)
     * @param FinancialRiskAssessmentType : Pass Financial Risk Assessment type(ex: Produnction Loss,Consequence etc)
     * @param RiskAssesmentValue : pass risk assessment value for a given financial risk assessment type
     */
    this.editRiskAssessmentFieldsInFinancialTab = function (RiskAssesmentType, FinancialRiskAssessmentType, RiskAssesmentValue) {
        var deferred = protractor.promise.defer();
        var xpathDynamic;
        if (RiskAssesmentType == RiskAssessmentType.MitigatedRisk) {
            xpathDynamic = element(by.xpath("//input[@name='mitigated-" + FinancialRiskAssessmentType.replace(" ", "-").toLowerCase() + "' and not(@disabled)]"));
        }
        if (RiskAssesmentType == RiskAssessmentType.UnMitigatedRisk) {
            xpathDynamic = element(by.xpath("//input[@name='unmitigated-" + FinancialRiskAssessmentType.replace(" ", "-").toLowerCase() + "' and not(@disabled)]"));
        }
        xpathDynamic.clear().sendKeys(RiskAssesmentValue).then(function (textEntered) {
            console.log("Entered text in " + FinancialRiskAssessmentType + " text box for " + RiskAssesmentType);
            deferred.fulfill(textEntered);
        });
        return deferred.promise;
    };

    /**
     * This will enter text in Basic for Assessment TextArea
     * @param basisAssesmentText : pass the text to be entered in basis for Assesment Text area
     */
    this.typeTextInBasicforAssessmentTextArea = function (basisAssessmentText) {
        var basicforAssessmentTextArea = element(by.xpath("//textarea[@name='basis-for-assessment']"));
        return promiseUtil.isElementDisplayed(basicforAssessmentTextArea).then(function () {
            return basicforAssessmentTextArea.clear().sendKeys(basisAssessmentText).then(function () {
                return true;
            })
        })
    };

    /**
     * This will save the Edited Risk Assesment
     */
    this.saveRiskAssessment = function () {
        var btnSaveRiskAssesment = element(by.xpath("//div[@class='risk-assessment-dialog']//button[@name='save']"));
        return promiseUtil.isElementDisplayed(btnSaveRiskAssesment).then(function () {
            return promiseUtil.click(btnSaveRiskAssesment);
        })
    };

    /**
     * This will Close the Risk Assestment with out saving
     */
    this.closeRiskAssessmentWithoutSaving = function () {
        var btnCloseRiskAssesment = element(by.xpath("//div[@class='risk-assessment-dialog']//button[@name='cancel']"));
        return promiseUtil.isElementDisplayed(btnCloseRiskAssesment).then(function () {
            return promiseUtil.click(btnCloseRiskAssesment);
        })
    }
};
module.exports = RiskMatrix;

