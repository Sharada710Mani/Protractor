function AssetHierarchy() {
    var self = this;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    var EC = protractor.ExpectedConditions;
    this.waitTime = 60000;

    //Search and Select
    this.openHierarchy = function () {
        var hierarchyTab = element(by.xpath("//i[@class='ds ds-assethierachy icon-dashboard-style']"));
        var searchButton = element(by.xpath("//section[@class='asset-hierarchy-control']//mi-searchbox[@class='btn btn-icon default-buttons-left']"));
        return promiseUtil.clickAndVerifyDisplayedElement(hierarchyTab, searchButton);
    }

    this.openSearchBox = function () {
        var searchButton = element(by.xpath("//section[@class='asset-hierarchy-control']//mi-searchbox[@class='btn btn-icon default-buttons-left']"));
        var searchBox = element(by.xpath("//section[@class='asset-hierarchy-control']//input[@class='form-control mi-searchbox']"));
        return browser.wait(EC.visibilityOf(searchButton), self.waitTime).then(function () {
            browser.actions().mouseMove(searchButton).perform();
            browser.actions().click().perform();
            browser.sleep(2000);//click issue
            return browser.wait(EC.visibilityOf(searchBox), self.waitTime).then(function () {
                return true;
            });
        });
    }

    this.closeSearchBox = function () {
        var searchButton = element(by.xpath("//section[@class='asset-hierarchy-control']//mi-searchbox[@class='btn btn-icon default-buttons-left']"));
        var searchBox = element(by.xpath("//section[@class='asset-hierarchy-control']//input[@class='form-control mi-searchbox']"));
        return browser.wait(EC.visibilityOf(searchBox), self.waitTime).then(function () {
            promiseUtil.sendKeys(searchBox,protractor.Key.TAB);
            browser.actions().mouseMove(searchButton).perform()
            browser.actions().click().perform();
            browser.sleep(2000);
            return browser.wait(EC.invisibilityOf(searchBox), self.waitTime).then(function () {
                return true;
            });
        });
    }

    this.typeTextInSearchBox = function (text) {
        var searchBox = element(by.xpath("//section[@class='asset-hierarchy-control']//input[@class='form-control mi-searchbox']"));
        return browser.wait(EC.visibilityOf(searchBox), self.waitTime).then(function () {
            return promiseUtil.sendKeys(searchBox,text).then(function () {
                return true;
            })
        })
    }

    this.clearSearchBox = function () {
        var searchBox = element(by.xpath("//section[@class='asset-hierarchy-control']//input[@class='form-control mi-searchbox']"));
        return browser.wait(EC.visibilityOf(searchBox), self.waitTime).then(function () {
            return promiseUtil.clear(searchBox).then(function () {
                return true;
            })
        })
    }

    this.searchAsset = function (asset) {
        var deferred = protractor.promise.defer();

        this.openSearchBox();
        this.typeTextInSearchBox(asset);
        var assetElement = element(by.xpath("(//section[@class='asset-hierarchy-control']//span[text()='" + asset + "'])[1]"));
        browser.wait(EC.presenceOf(assetElement), self.waitTime).then(function (result) {
            deferred.fulfill(result);
        })

        return deferred.promise;
    }

    this.openHierarchyAndSearchAsset = function (asset) {
        return self.openHierarchy().then(function () {
            return self.searchAsset(asset);
        })
    }

    this.selectAsset = function (asset) {
        var assetElement = element(by.xpath("(//section[@class='asset-hierarchy-control']//mi-li[@class='list-group-item']//span[text()='" + asset + "'])[1]"));
        var assetTitle = element(by.xpath("//span[@data-bind='text: title' and text()='" + asset + "']"))
        return promiseUtil.clickAndVerifyDisplayedElement(assetElement, assetTitle);
    }

    this.selectAssetByPartialText = function (asset) {
        var assetElement = element(by.xpath("(//section[@class='asset-hierarchy-control']//mi-li[@class='list-group-item']//span[contains(text(),'" + asset + "')])[1]"));
        var assetTitle = element(by.xpath("//span[@data-bind='text: title' and contains(text(),'" + asset + "')]"))
        return promiseUtil.clickAndVerifyDisplayedElement(assetElement, assetTitle);
    }

    this.selectAssetByIndex = function (index) {
        var deferred = protractor.promise.defer();
        var assetElement = element(by.xpath("(//section[@class='asset-hierarchy-control']//mi-li[@class='list-group-item']//span[@class='system-ellipsis-text'])[" + index + "]"));
        promiseUtil.getDisplayedElementText(assetElement).then(function (assetText) {
            self.selectAsset(assetText).then(function (result) {
                deferred.fulfill(result);
            })
        })
        return deferred.promise;
    }

    this.searchAndSelectAsset = function (asset) {
        return self.searchAsset(asset).then(function () {
            return self.selectAsset(asset);
        })
    }

    this.searchAndSelectAssetByPartialText = function (asset) {
        return self.searchAsset(asset).then(function () {
            return self.selectAssetByPartialText(asset);
        })
    }

    this.searchAndSelectAssetByIndex = function (asset,index) {
        return self.searchAsset(asset).then(function () {
            return self.selectAssetByIndex(index);
        })
    }

    this.openHierarchyAndSelectSearchedAsset = function (asset) {
        return self.openHierarchy().then(function () {
            return self.searchAndSelectAsset(asset);
        })
    }

    this.openHierarchyAndSelectSearchedAssetByPartialText = function (asset) {
        return self.openHierarchy().then(function () {
            return self.searchAndSelectAssetByPartialText(asset);
        })
    }

    this.openHierarchyAndSelectSearchedAssetByIndex = function (asset,index) {
        return self.openHierarchy().then(function () {
            return self.searchAndSelectAssetByIndex(asset,index);
        })
    }


    //Expand/Back
    this.expandAsset = function (asset) {
        var assetExpandButton = element(by.xpath("(((//section[@class='asset-hierarchy-control']//mi-li[@class='list-group-item']//span[text()='" + asset + "'])/..)/following-sibling::i[@class='icon-right-arrow'])[1]"));
        return promiseUtil.click(assetExpandButton);
    }

    this.expandAssetByPartialText = function (asset) {
        var assetExpandButton = element(by.xpath("(((//section[@class='asset-hierarchy-control']//mi-li[@class='list-group-item']//span[contains(text(),'" + asset + "')])/..)/following-sibling::i[@class='icon-right-arrow'])[1]"));
        return promiseUtil.click(assetExpandButton);
    }

    this.expandAssetByIndex = function (index) {
        var assetExpandButton = element(by.xpath("(((//section[@class='asset-hierarchy-control']//span)/..)/following-sibling::i[@class='icon-right-arrow'])[" + index + "]"));
        return promiseUtil.click(assetExpandButton);
    }

    this.back = function () {
        var backButton = element(by.xpath("//section[@class='asset-hierarchy-control']//i[@class='icon-back-arrow']"))
        return promiseUtil.click(backButton);
    }


    //Asset Tabs
    this.selectAssetModuleTab = function (tabText) {
        var tabElement = element(by.xpath("//section[@class='asset-hierarchy-content']//mi-tab-group//mi-tab//span[@class='text' and text()='" + tabText + "']"));
        var selectedTabElement = element(by.xpath("//section[@class='asset-hierarchy-content']//div[contains(@class,'active')]//span[@class='text' and text()='" + tabText + "']"));
        return promiseUtil.clickAndVerifyDisplayedElement(tabElement, selectedTabElement);
    }

    this.selectAssetModuleTabByPartialText = function (tabText) {
        var tabElement = element(by.xpath("(//section[@class='asset-hierarchy-content']//mi-tab-group//mi-tab//span[@class='text' and contains(text(),'" + tabText + "')])[1]"));
        var selectedTabElement = element(by.xpath("//section[@class='asset-hierarchy-content']//div[contains(@class,'active')]//span[@class='text' and contains(text(),'" + tabText + "')]"));
        return promiseUtil.clickAndVerifyDisplayedElement(tabElement, selectedTabElement);
    }

    this.selectAssetModuleTabByIndex = function (index) {
        var tabElement = element(by.xpath("(//section[@class='asset-hierarchy-content']//mi-tab-group//mi-tab//span[@class='text'])[" + index + "]"));
        return promiseUtil.getDisplayedElementText(tabElement).then(function (text) {
            var selectedTabElement = element(by.xpath("//section[@class='asset-hierarchy-content']//div[contains(@class,'active')]//span[@class='text' and text()='" + text + "']"));
            return promiseUtil.clickAndVerifyDisplayedElement(tabElement, selectedTabElement);
        })
    }

    this.getSelectedAssetModuleTabText = function () {
        var selectedTabElement = element(by.xpath("//section[@class='asset-hierarchy-content']//div[contains(@class,'active')]//span[@class='text']"));
        return promiseUtil.getDisplayedElementText(selectedTabElement);
    }

    this.getAllAssetModulesTabText = function () {
        var assetModulesTabsLocator = by.xpath("//section[@class='asset-hierarchy-content']//mi-tab-group//mi-tab//span[@class='text']")
        return promiseUtil.getAllText(assetModulesTabsLocator);
    }

    this.getAssetModuleTabTextByIndex = function (index) {
        var tabElement = element(by.xpath("(//section[@class='asset-hierarchy-content']//mi-tab-group//mi-tab//span[@class='text'])[" + index + "]"));
        return promiseUtil.getDisplayedElementText(tabElement);

    }


    //Modules
    this.getAllAssetModulesText = function () {
        var assetModulesLocator = by.xpath("//section[@class='asset-hierarchy-content']//table[contains(@class,'active')]//td[contains(@data-bind,'module')]");
        return promiseUtil.getAllText(assetModulesLocator);
    }

    this.getAssetModuleTextByIndex = function (index) {
        var assetModuleLocator = element(by.xpath("(//section[@class='asset-hierarchy-content']//table[contains(@class,'active')]//td[contains(@data-bind,'module')])[" + index + "]"));
        return promiseUtil.getDisplayedElementText(assetModuleLocator);
    }


    //Resources
    this.getAllResourcesText = function () {
        var resourceLocator = by.xpath("//section[@class='asset-hierarchy-content']//table[contains(@class,'active')]//a");
        return promiseUtil.getAllText(resourceLocator);
    }

    this.getResourceTextByIndex = function (index) {
        var resource = element(by.xpath(("(//section[@class='asset-hierarchy-content']//table[contains(@class,'active')]//a)[" + index + "]")));
        return promiseUtil.getDisplayedElementText(resource);
    }

    this.getResourceTextByAssetModule = function (assetModulesText) {
        var resourceLocator = element(by.xpath("(//section[@class='asset-hierarchy-content']//table[contains(@class,'active')]//td[contains(@data-bind,'module') and text()='" + assetModulesText + "']/..)//span"));
        return promiseUtil.getDisplayedElementText(resourceLocator);

    }

    this.openResource = function (resourceText) {
        var resource = element(by.xpath("((//section[@class='asset-hierarchy-content']//table[contains(@class,'active')])//a//span[text()='" + resourceText + "'])[1]"));
        return promiseUtil.click(resource);
    }

    this.openResourceByIndex = function (index) {
        var resource = element(by.xpath(("((//section[@class='asset-hierarchy-content']//table[contains(@class,'active')])//a//span)[" + index + "]")));
        return promiseUtil.click(resource);

    }

    this.openResourceByPartialText = function (partialResourceText) {
        var resource = element(by.xpath("((//section[@class='asset-hierarchy-content']//table[contains(@class,'active')])//a//span[contains(text(),'" + partialResourceText + "')])[1]"));
        return promiseUtil.click(resource);
    }

    this.openResourceByAssetModule = function (assetModulesText) {
        var resource = element(by.xpath("(//section[@class='asset-hierarchy-content']//table[contains(@class,'active')]//td[contains(@data-bind,'module') and text()='" + assetModulesText + "']/..)//a"));
        return promiseUtil.click(resource);
    }


    //Filter
    this.openFilter = function () {
        var filterButton = element(by.xpath("//section[@class='asset-hierarchy-control']//mi-tool-bar-filter[@class='btn btn-default btn-icon default-buttons-left']//i"));
        var filterTitle = element(by.xpath("//div[@class='popover fade bottom in']//h3[text()='Filter']"));
        return browser.wait(EC.visibilityOf(filterButton), self.waitTime).then(function () {
            browser.actions().mouseMove(filterButton).perform();
            browser.actions().click().perform();
            browser.sleep(2000);//click issue
            return browser.wait(EC.visibilityOf(filterTitle), self.waitTime).then(function () {

                return true;
            });
        });
    }

    this.closeFilter = function () {
        var filterButton = element(by.xpath("//section[@class='asset-hierarchy-control']//mi-tool-bar-filter[@class='btn btn-default btn-icon default-buttons-left']//i"));
        var filterTitle = element(by.xpath("//div[@class='popover fade bottom in']//h3[text()='Filter']"));
        return browser.wait(EC.visibilityOf(filterButton), self.waitTime).then(function () {
            browser.actions().mouseMove(filterButton).perform()
            browser.actions().click().perform();
            browser.sleep(2000);
            return browser.wait(EC.invisibilityOf(filterTitle), self.waitTime).then(function () {
                return true;
            });
        });
    }

    this.applyFilter = function () {
        var btnApplyFilter = element(by.xpath("//div[@class='popover fade bottom in']//button[text()='Apply']"));
        return browser.wait(EC.visibilityOf(btnApplyFilter), self.waitTime).then(function () {
            browser.actions().mouseMove(btnApplyFilter).perform();
            browser.actions().click().perform();
            browser.sleep(2000);//click issue
            return browser.wait(EC.invisibilityOf(btnApplyFilter), self.waitTime).then(function () {
                return true;
            });
        });
    }

    this.openHierarchyAndApplyFilter = function () {
        return self.openHierarchy().then(function () {
            return self.openFilter().then(function () {
                return self.applyFilter();
            })
        })
    }

    this.resetFilter = function () {
        var deferred = protractor.promise.defer();
        var categoryResetText = "Select a Category...";
        var classResetText = "Select a Class...";
        var typeResetText = "Select a Type...";

        self.selectCategoryFilter(categoryResetText);
        self.selectClassFilter(classResetText);
        self.selectTypeFilter(typeResetText);

        self.applyFilter().then(function (displayed) {
            deferred.fulfill(displayed);
        })

        return deferred.promise;
    }

    this.openHierarchyAndResetFilter = function () {
        return self.openHierarchy().then(function () {
            return self.openFilter().then(function () {
                return self.resetFilter();
            })
        })
    }

    this.selectCategoryFilter = function (categoryFilterOption) {
        var ddlCategory = element(by.xpath("((//div[@class='popover fade bottom in']//label[text()='Category'])/..)//select"));
        var ddlCategoryOption = element(by.xpath("((//div[@class='popover fade bottom in']//label[text()='Category'])/..)//select//option[text()='" + categoryFilterOption + "']"));
        return browser.wait(EC.visibilityOf(ddlCategory), self.waitTime).then(function () {
            return promiseUtil.isElementPresent(ddlCategoryOption).then(function () {
                return promiseUtil.click(ddlCategoryOption);
            })
        })
    }

    this.selectClassFilter = function (classFilterOption) {
        var ddlClass = element(by.xpath("((//div[@class='popover fade bottom in']//label[text()='Class'])/..)//select"));
        var ddlClassOption = element(by.xpath("((//div[@class='popover fade bottom in']//label[text()='Class'])/..)//select//option[text()='" + classFilterOption + "']"));
        return browser.wait(EC.visibilityOf(ddlClass), self.waitTime).then(function () {
            return promiseUtil.isElementPresent(ddlClassOption).then(function () {
                return promiseUtil.click(ddlClassOption);
            })
        })
    }

    this.selectTypeFilter = function (typeFilterOption) {
        var ddlType = element(by.xpath("((//div[@class='popover fade bottom in']//label[text()='Type'])/..)//select"));
        var ddlTypeOption = element(by.xpath("((//div[@class='popover fade bottom in']//label[text()='Type'])/..)//select//option[text()='" + typeFilterOption + "']"));
        return browser.wait(EC.visibilityOf(ddlType), self.waitTime).then(function () {
            return promiseUtil.isElementPresent(ddlTypeOption).then(function () {
                return promiseUtil.click(ddlTypeOption);
            })
        })
    }

    this.selectFilter = function (categoryFilterOption, classFilterOption, typeFilterOption) {
        var deferred = protractor.promise.defer();

        if (categoryFilterOption)
            self.selectCategoryFilter(categoryFilterOption);
        if (classFilterOption)
            self.selectClassFilter(classFilterOption);
        if (typeFilterOption)
            self.selectTypeFilter(typeFilterOption);
        
        deferred.fulfill(true);
            
        return deferred.promise;
    }

    this.openHierarchyAndSelectFilter = function (categoryFilterOption, classFilterOption, typeFilterOption) {
        return self.openHierarchy().then(function () {
            return self.openFilter().then(function () {
                return self.selectFilter(categoryFilterOption, classFilterOption, typeFilterOption);
            })
        })
    }

    this.selectAndApplyFilter = function (categoryFilterOption, classFilterOption, typeFilterOption) {
        var deferred = protractor.promise.defer();

        if (categoryFilterOption)
            self.selectCategoryFilter(categoryFilterOption);
        if (classFilterOption)
            self.selectClassFilter(classFilterOption);
        if (typeFilterOption)
            self.selectTypeFilter(typeFilterOption);
        self.applyFilter().then(function (displayed) {
            deferred.fulfill(displayed);
        })

        return deferred.promise;
    }

    this.openHierarchyAndSelectApplyFilter = function (categoryFilterOption, classFilterOption, typeFilterOption) {
        return self.openHierarchy().then(function () {
            return self.openFilter().then(function () {
                return self.selectAndApplyFilter(categoryFilterOption, classFilterOption, typeFilterOption);
            })
        })
    }
}
module.exports = AssetHierarchy;
