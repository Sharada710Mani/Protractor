'use strict';

var promiseUtilFile = require('../PageObjects/promise-utils-po.js');
var promiseUtil = new promiseUtilFile();

var objManager = require('ProUI-Utils').ObjectManager;
var objectManager = new objManager();
var globalObjectManager = objectManager.getGlobalObjectManager("toastMessages");
var TestHelper = globalObjectManager.TestHelper;
var ElementManager = globalObjectManager.ElementManager;




var ToastMessages = function () {


    /**
     * This will check if success toast message is displayed
     * @returns {*}
     */
    this.isSuccessMessageDisplayed = function () {

        var successElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-success']"));
        return promiseUtil.isElementDisplayed(successElement);
    };

    /**
     * This will wait until success toast message disappears
     * @returns {*}
     */
    this.isSuccessMessageNotDisplayed = function () {
        var successElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-success']"));
        return promiseUtil.isElementNotDisplayed(successElement);
    };

    /**
     * This functions verifies success toast message
     * @param {*} msg : text to be validated in success message
     */
    this.verifySuccessMessage = function (msg) {
        return TestHelper.textToBePresentInElement("toastMessages", "successElement", msg);

    };

    /**
     * This will return Success toast message text
     */
    this.getSuccessMessage = function () {
        var deferred = protractor.promise.defer();
        var successElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-success']/div[@class='toast-message']"));
        promiseUtil.isElementDisplayed(successElement).then(function (status) {
            console.log(status);
            if (status == true) {
                successElement.getText()
                    .then(function (successmsg) {
                        deferred.fulfill(successmsg);
                    });
            }
            else {deferred.fulfill(false);}
        });
        return deferred.promise;
    };

    /**
     * This will check if error toast message is displayed
     * @returns {*}
     */
    this.isErrorMessageDisplayed = function () {
        var errorElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-error']"));
        return promiseUtil.isElementDisplayed(errorElement);
    };


    /**
     * This will wait untill error toast message disappears
     * @returns {*}
     */
    this.isErrorMessageNotDisplayed = function () {
        var errorElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-error']"));
        return promiseUtil.isElementNotDisplayed(errorElement);
    };

    /**
     * This functions verifies error toast message
     * @param {*} msg : text to be validated in error message
     */
    this.verifyErrorMessage = function (msg) {
        return TestHelper.textToBePresentInElement("toastMessages", "errorElement", msg);
    };

    /**
     * This will return error toast message text
     */
    this.getErrorMessage = function () {

        var deferred = protractor.promise.defer();
        var errorElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-error']/div[@class='toast-message']"));
        promiseUtil.isElementDisplayed(errorElement).then(function (status) {
            if (status == true) {
                errorElement.getText()
                    .then(function (errmsg) {
                        deferred.fulfill(errmsg);
                    });
            }
            else {deferred.fulfill(false);}
        });
        return deferred.promise;
    };

    /**
     * This will check if warning toast message is displayed
     * @returns {*}
     */
    this.isWarningMessageDisplayed = function () {

        var warningElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-warning']"));
        return promiseUtil.isElementDisplayed(warningElement);
    };

    /**
     * This will wait untill warning toast message disappears
     * @returns {*}
     */
    this.isWarningMessageNotDisplayed = function () {
        var warningElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-warning']"));
        return promiseUtil.isElementNotDisplayed(warningElement);
    };


    /**
     * This functions verifies warning toast message
     * @param {*} msg : text to be validated in warning message
     */
    this.verifyWariningMessage = function (msg) {
        return TestHelper.textToBePresentInElement("toastMessages", "warningElement", msg);
    };

    /**
     * This will return warning toast message text
     */
    this.getWarningMessage = function () {
        var warningElement = element(by.xpath("//div[@id='toast-container']/div[@class='toast toast-warning']/div[@class='toast-message']"));
        promiseUtil.isElementDisplayed(warningElement).then(function (status) {
            if (status == true) {
                warningElement.getText()
                    .then(function (wrngmsg) {
                        deferred.fulfill(wrngmsg);
                    });
            }
            else {deferred.fulfill(false);}
        });
        return deferred.promise;
    };


};
module.exports = ToastMessages;

