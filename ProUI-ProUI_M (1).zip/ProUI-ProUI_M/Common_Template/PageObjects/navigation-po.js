function NavigationPage() {
    'use strict';
    var self = this;
    var EC = protractor.ExpectedConditions;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js')
    var promiseUtil = new promiseUtilFile();
    var currentPage = 'navigation';
    var objectManager = require('proui-utils').ObjectManager;
    var navigationObjectManager = new objectManager();
    var navigationElementManager = navigationObjectManager.getGlobalObjectManager(currentPage).ElementManager;

    this.navigateToScreen = function (menu, subMenu) {
        var strMainMenu = "mnu" + menu;
        var strSubMenu = "lnk" + subMenu;
        var titleSubMenu = "title" + subMenu;
        var element = navigationElementManager.findElement(currentPage, strMainMenu);
        return promiseUtil.getDisplayedElement(element)
            .then(self.clickMainMenu.bind(null, strMainMenu))
            .then(self.clickMainMenuDone.bind(null, strSubMenu))
            .then(self.clickSubMenu.bind(null, strSubMenu))
            .then(self.clickSubMenuDone.bind(null, titleSubMenu));
    }

    this.clickMainMenu = function (strMainMenu) {
        var elementMainMenu = navigationElementManager.findElement(currentPage, strMainMenu);
        return promiseUtil.getDisplayedElement(elementMainMenu).then(function(){
            return promiseUtil.click(elementMainMenu);
        })
    }

    this.clickMainMenuDone = function (strSubMenu) {
        var elementSubMenu = navigationElementManager.findElement(currentPage, strSubMenu);
        return promiseUtil.getDisplayedElement(elementSubMenu);
    }

    this.clickSubMenu = function (strSubMenu) {
        var elementSubMenu = navigationElementManager.findElement(currentPage, strSubMenu);
        return promiseUtil.getPresentElement(elementSubMenu).then(function(){
            return promiseUtil.click(elementSubMenu);
        })
    }

    this.clickSubMenuDone = function (titleSubMenu) {
        var elementSubMenu = navigationElementManager.findElement(currentPage, titleSubMenu);
        return promiseUtil.getDisplayedElement(elementSubMenu);
    }
}
module.exports =  new NavigationPage();



