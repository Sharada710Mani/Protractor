function SiteSelector(siteElement) {
    'use strict';
    var self = this;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js');
    var promiseUtil = new promiseUtilFile();

    if (arguments.length == 0)
        this.siteElement = element(by.xpath("(//mi-site-selector)[1]"));
    else
        this.siteElement = siteElement;


    this.getSiteSelector = function () {
        return promiseUtil.getDisplayedElement(self.siteElement);
    };

    this.isSiteSelectorEnabled = function () {
        var deferred = protractor.promise.defer();

        promiseUtil.getDisplayedElement(self.siteElement).then(function (element) {
            element.getAttribute('readonly').then(function (attributeValue) {
                if (attributeValue)
                    return false;
                else
                    return true;
            }).then(function (data) {
                deferred.fulfill(data);
            });
        });

        return deferred.promise;
    };

    this.selectSiteByText = function (siteText) {
        return self.getSiteSelector().then(function (site) {
            browser.actions().click(site).perform();

            if (!siteText) {
                siteText = 'Global';
            }
            var siteOption = site.element(by.xpath("//div[@class='dropdown open']//li[text()='" + siteText + "']"));
            return promiseUtil.getPresentElement(siteOption).then(function (siteOptionElement) {
                return promiseUtil.click(siteOptionElement).then(function () {
                    return true;
                });
            });
        });
    };

    this.selectSiteByPartialText = function (partialSiteText) {
        return self.getSiteSelector().then(function (site) {
            browser.actions().click(site).perform();
            var siteOption = site.element(by.xpath("//div[@class='dropdown open']//li[contains(text(),'" + partialSiteText + "')][1]"));
            return promiseUtil.getPresentElement(siteOption).then(function (siteOptionElement) {
                return promiseUtil.click(siteOptionElement).then(function () {
                    return true;
                });
            });
        });
    };

    this.selectSiteByIndex = function (index) {
        return self.getSiteSelector().then(function (site) {
            browser.actions().click(site).perform();
            var siteOption = site.element(by.xpath("//div[@class='dropdown open']//li[" + index + "]"));
            return promiseUtil.getDisplayedElement(siteOption).then(function (siteOptionElement) {
                return promiseUtil.click(siteOptionElement).then(function () {
                    return true;
                });
            });
        });
    };

    this.getAllSitesText = function () {
        return self.getSiteSelector().then(function (site) {
            var siteOptions = site.all(by.tagName("li"));
            return promiseUtil.getAllElementsAttribute(siteOptions, 'title').then(function (list) {
                return list;
            });
        });
    };

    this.getAllSitesCount = function () {
        return self.getSiteSelector().then(function (site) {
            var siteOptions = site.all(by.tagName("li"));
            return siteOptions.count().then(function (count) {
                return count;
            });
        });
    };

    this.getSelectedSiteText = function () {
        return self.getSiteSelector().then(function (site) {
            var selectedSite = site.element(by.xpath("//output"));
            return promiseUtil.getDisplayedElementText(selectedSite).then(function (text) {
                return text;
            });
        });
    };
}
module.exports = SiteSelector;

