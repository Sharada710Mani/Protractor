function AssetPopupSearch(siteElement) {
    'use strict';
    var self = this;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js');
    var apmSelectFile = require('../PageObjects/apm-select-po.js');
    var promiseUtil = new promiseUtilFile();

    this.isOpen = function () {
        var assetPopupLocator = by.xpath("//div[@class='dialog-wrapper']//div[@class='title-container' and text()='Search']");
        return element.all(assetPopupLocator).count().then(function (count) {
            return count > 0;
        });
    };

    this.accept = function () {
        var okButton = element(by.xpath("//div[@class='dialog-wrapper']//button[text()='OK']"));
        return promiseUtil.click(okButton).then(function () {
            return promiseUtil.isElementNotDisplayed(okButton).then(function (result) {
                return result;
            });
        });
    };

    this.reject = function () {
        var cancelButton = element(by.xpath("//div[@class='dialog-wrapper']//button[text()='Cancel']"));
        return promiseUtil.click(cancelButton).then(function () {
            return promiseUtil.isElementNotDisplayed(cancelButton).then(function (result) {
                return result;
            });
        });
    };

    this.submitSearch = function () {
        var searchButton = element(by.xpath("//div[@class='dialog-wrapper']//button[@class='btn search-options-current-selection']"));
        return promiseUtil.click(searchButton).then(function (result) {
            return result;
        });
    };

    this.getFamiliesAPMSelect = function () {
        var locator = element(by.xpath("//div[@class='dialog-wrapper']//mi-select[@name='families']"));
        return promiseUtil.getDisplayedElement(locator).then(function (ele) {
            var familiesAPMSelect = new apmSelectFile(ele);
            return familiesAPMSelect;
        });
    };

    this.getRelationshipsAPMSelect = function () {
        var locator = element(by.xpath("//div[@class='dialog-wrapper']//mi-select[@name='relationships']"));
        return promiseUtil.getDisplayedElement(locator).then(function (ele) {
            var relationshipsAPMSelect = new apmSelectFile(ele);
            return relationshipsAPMSelect;
        });
    };

    this.getSearchBox = function () {
        var searchBox = element(by.xpath("//div[@class='dialog-wrapper']//input[@class='form-control search-term block']"));
        return promiseUtil.getDisplayedElement(searchBox).then(function (ele) {
            return ele;
        });
    };

    this.getAllAssetElements = function () {
        var locator = by.xpath("//div[@class='dialog-wrapper']//section[@class='global-search-results']//li[@class='list-group-item']");
        return promiseUtil.getAll(locator).then(function (assetElements) {
            return assetElements;
        });
    };

    this.getAllAssetElementsByText = function (assetText) {
        var locator = by.xpath("(//div[@class='dialog-wrapper']//h4[text()='" + assetText + "']/../..)");
        return promiseUtil.getAll(locator).then(function (assetElements) {
            return assetElements;
        });
    };

    this.getAllAssetElementsByPartialText = function (partialAssetText) {
        var locator = by.xpath("(//div[@class='dialog-wrapper']//h4[contains(text(),'" + partialAssetText + "')]/../..)");
        return promiseUtil.getAll(locator).then(function (assetElements) {
            return assetElements;
        });
    };

    this.getAssetElementByIndex = function (index) {
        var locator = by.xpath("(//div[@class='dialog-wrapper']//section[@class='global-search-results']//li[@class='list-group-item'])");
        return promiseUtil.getByIndex(locator, index).then(function (assetElement) {
            return assetElement;
        });
    };

    this.getAssetElementByText = function (assetText) {
        var assetElement = element(by.xpath("(//div[@class='dialog-wrapper']//h4[text()='" + assetText + "']/../..)[1]"));
        return promiseUtil.getDisplayedElement(assetElement).then(function (ele) {
            return ele;
        });
    };

    this.getAssetElementByPartialText = function (partialAssetText) {
        var assetElement = element(by.xpath("(//div[@class='dialog-wrapper']//h4[contains(text(),'" + partialAssetText + "')]/../..)[1]"));
        return promiseUtil.getDisplayedElement(assetElement).then(function (ele) {
            return ele;
        });
    };

    this.selectAssetByIndex = function (index) {
        var locator = by.xpath("//div[@class='dialog-wrapper']//span[@class='radio-label']");
        return promiseUtil.getByIndex(locator, index).then(function (radioButton) {
            return promiseUtil.click(radioButton).then(function (result) {
                return result;
            });
        });
    };

    this.selectAssetByText = function (assetText) {
        var locator = by.xpath("(//div[@class='dialog-wrapper']//h4[text()='" + assetText + "']/../..)//span[@class='radio-label']");
        return promiseUtil.getByIndex(locator, 1).then(function (radioButton) {
            return promiseUtil.click(radioButton).then(function (result) {
                return result;
            });
        });
    };

    this.selectAssetByPartialText = function (partialAssetText) {
        var locator = by.xpath("(//div[@class='dialog-wrapper']//h4[contains(text(),'" + partialAssetText + "')]/../..)//span[@class='radio-label']");
        return promiseUtil.getByIndex(locator, 1).then(function (radioButton) {
            return promiseUtil.click(radioButton).then(function (result) {
                return result;
            });
        });
    };

    this.searchAsset = function (assetText) {
        var deferred = protractor.promise.defer();

        self.getSearchBox().then(function (searchBox) {
            promiseUtil.sendKeys(searchBox,assetText).then(function () {
                self.submitSearch().then(function (result) {
                    deferred.fulfill(result);
                });
            });
        });

        return deferred.promise;
    };

    this.searchAndLinkAsset = function (assetText) {
        return self.searchAsset(assetText).then(function () {
            return self.selectAssetByText(assetText).then(function () {
                return self.accept().then(function (result) {
                    return result;
                });
            });
        });
    };

    this.searchAndLinkAssetByPartialText = function (partialAssetText) {
        return self.searchAsset(partialAssetText).then(function () {
            return self.selectAssetByPartialText(partialAssetText).then(function () {
                return self.accept().then(function (result) {
                    return result;
                });
            });
        });
    };
}
module.exports = AssetPopupSearch;

