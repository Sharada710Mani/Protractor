/**
 * Created by nekumar on 9/7/2017.
 */


module.exports = Object.freeze({
    forwardSlash : "//",
    singleSlash:"/",
    tagName : "div",
    tagNameClass:"class",
    openingBracket : "[",
    labelTextValue : "",
    closingBracket : "]",
    comparerText : "text()=",
    singleQuote : "'",
    containsText : "",
    followingTag : "following::",
    followedTextTag : "input",
    followedTextAreaTag : "textarea",
    firstArrayElement : "[1]",
    openingBraces :"(",
    closingBraces :")",
    at: "@",
    equal: "=",
    anchorTag: "a",
    parentTag:"parent::",
    tagH4:"h4",
    equals :"=",
    tagSpan:"span",
    tagParagraph:"p"





});


