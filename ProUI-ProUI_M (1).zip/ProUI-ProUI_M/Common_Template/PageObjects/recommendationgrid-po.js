
// var testData = require('../TestData/reliability-test-data.json');
var testHelperLocal = require('ProUI-Utils').TestHelper;
var  lem= new ElementManager('../../../Test_Modules/KT_Practice_2205_Reliability/reliability-cases-element-repo.json');
  testHelperLocal.setElementManager(lem);
   // var SelectWrapper = require('../utils/select-wrapper.js');
    var recomPage = function () {


        var currentPage = 'recomPage';
        // var reliabElementRepo = new ElementManager('C:/GE/Projects/ProUI/Test_Modules/KT_Practice_2205_Reliability/reliability-element-repo.json');
            this.clickDropDownArrow=function () {
                TestHelper.iFrameSwitch('landingPage', 'iframe');
                console.log("PAge44444444444444444 ="+ currentPage);

                return lem.findElement(currentPage,'downArrow').click();
            },

            this.clickOnTools=function(){
                return TestHelper.elementToBeClickable("landingPage",'reliabilityTab');
               // return  element(by.xpath("//div[@class='left-nav-main-menu']//a[text()='Tools']")).click();
            },
            this.clickToolsAndDashboard=function(){
               // var _self = this;
              return  this.clickOnTools().then(function(text){
                  console.log("@@@@  "+text);
                  return testHelperLocal.elementToBeClickable("landingPage",'caseLink');

                })
            },
            this.selectFromDropDownByText=function () {
               // browser.sleep(10000);
                return lem.findElement(currentPage,'myCasesListItem').click();
            //   return TestHelperPO.elementToBeClickable(currentPage,'myCasesListItem');

            },

            this.getAllCases=function(){
              // var array = lem.findElements(currentPage,'caseArray');
               var ele= element.all(by.xpath("//ul[@class='scroll-area case-inbox list-bare']//li"));
                var expected = ['expect1', 'expect2', 'expect3'];
                for (var i = 0; i < 1; ++i) {
                    ele.get(i).getText().then(function(text) {
                        console.log(text+"  *********");
                      //  expect(text).toEqual(expected[i]); // Error: `i` is always 3.
                    })
                }

            }



    }

    module.exports = new recomPage ;

