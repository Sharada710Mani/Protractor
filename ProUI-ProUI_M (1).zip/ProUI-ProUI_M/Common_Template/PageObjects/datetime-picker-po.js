function DateTimePicker(dateTimePickerElement) {
    'use strict';
    var self = this;
    var promiseUtilFile = require('../PageObjects/promise-utils-po.js');
    var promiseUtil = new promiseUtilFile();
    var calenderMonths = { "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04", "May": "05", "Jun": "06", "Jul": "07", "Aug": "08", "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12" };

    if (arguments.length == 0)
        this.dateTimePicker = element(by.xpath("(//mi-date-time)[1]"));
    else
        this.dateTimePicker = dateTimePickerElement;

    this.open = function () {
        return promiseUtil.getPresentElement(self.dateTimePicker).then(function (picker) {
            return promiseUtil.click(picker.element(by.xpath("..")).element(by.tagName("input"))).then(function () {
                return self.isOpen().then(function (result) {
                    return result;
                });
            });
        });
    };

    this.close = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var closeElementLocator = element(by.xpath("//div[contains(@class,'bootstrap-datetimepicker-widget') and contains(@style,'display: block;')]//button[text()='Close']"));
            promiseUtil.getDisplayedElement(closeElementLocator).then(function (closeElement) {
                promiseUtil.click(closeElement).then(function () {
                    deferred.fulfill(true);
                });
            });
        });

        return deferred.promise;
    };

    this.isOpen = function () {
        var calenderPopupLocator = by.xpath("//div[contains(@class,'bootstrap-datetimepicker-widget') and contains(@style,'display: block;')]");
        return element.all(calenderPopupLocator).count().then(function (count) {
            return count > 0;
        });
    };

    this.isEnabled = function () {
        return promiseUtil.getPresentElement(self.dateTimePicker).then(function (picker) {
            return picker.getAttribute('disabled').then(function (result) {
                if (result)
                    return false;
                else
                    return true;
            });
        });
    };

    this.clear = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var clearElementLocator = element(by.xpath("//div[contains(@class,'bootstrap-datetimepicker-widget') and contains(@style,'display: block;')]//button[text()='Clear']"));
            promiseUtil.getDisplayedElement(clearElementLocator).then(function (clearElement) {
                promiseUtil.click(clearElement).then(function () {
                    deferred.fulfill(true);
                });
            });
        });

        return deferred.promise;
    };

    this.getHours = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var hourElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//span[@data-action='showHours']"));
            promiseUtil.getPresentElement(hourElementLocator).then(function (hourElement) {
                hourElement.getAttribute('innerHTML').then(function (hour) {
                    deferred.fulfill(hour);
                });
            });
        });

        return deferred.promise;
    };

    this.setHours = function (hours) {
        return self.getMinutes().then(function (minutes) {
            return self.getSeconds().then(function (seconds) {
                return self.getTimePeriod().then(function (timePeriod) {
                    var updatedTime = hours + ":" + minutes + ":" + seconds + " " + timePeriod;
                    return self.setTime(updatedTime).then(function (updatedTime) {
                        return true;
                    });
                });
            });
        });
    };

    this.getMinutes = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var minuteElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//span[@data-action='showMinutes']"));
            promiseUtil.getPresentElement(minuteElementLocator).then(function (minuteElement) {
                minuteElement.getAttribute('innerHTML').then(function (minutes) {
                    deferred.fulfill(minutes);
                });
            });
        });

        return deferred.promise;
    };

    this.setMinutes = function (minutes) {
        return self.getHours().then(function (hours) {
            return self.getSeconds().then(function (seconds) {
                return self.getTimePeriod().then(function (timePeriod) {
                    var updatedTime = hours + ":" + minutes + ":" + seconds + " " + timePeriod;
                    return self.setTime(updatedTime).then(function (updatedTime) {
                        return true;
                    });
                });
            });
        });
    };

    this.getSeconds = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var secondElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//span[@data-action='showSeconds']"));
            promiseUtil.getPresentElement(secondElementLocator).then(function (secondElement) {
                secondElement.getAttribute('innerHTML').then(function (seconds) {
                    deferred.fulfill(seconds);
                });
            });
        });

        return deferred.promise;
    };

    this.setSeconds = function (seconds) {
        return self.getHours().then(function (hours) {
            return self.getMinutes().then(function (minutes) {
                return self.getTimePeriod().then(function (timePeriod) {
                    var updatedTime = hours + ":" + minutes + ":" + seconds + " " + timePeriod;
                    return self.setTime(updatedTime).then(function (updatedTime) {
                        return true;
                    });
                });
            });
        });
    };

    this.getTimePeriod = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var timePeriodElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//button[@data-action='togglePeriod']"));
            promiseUtil.getPresentElement(timePeriodElementLocator).then(function (timePeriodElement) {
                timePeriodElement.getAttribute('innerHTML').then(function (timePeriod) {
                    deferred.fulfill(timePeriod);
                });
            });
        });

        return deferred.promise;
    };

    this.setTimePeriod = function (timePeriod) {
        return self.getDateTime().then(function (datetime) {
            return self.getTimePeriod().then(function (currentTimePeriod) {
                var updatedDateTime = datetime.replace(currentTimePeriod, "timePeriod").replace('timePeriod', timePeriod);
                return self.setDateTime(updatedDateTime).then(function () {
                    return true;
                });
            });
        });
    };

    this.getTime = function () {
        return self.getHours().then(function (hours) {
            return self.getMinutes().then(function (minutes) {
                return self.getSeconds().then(function (seconds) {
                    return self.getTimePeriod().then(function (timePeriod) {
                        return hours + ":" + minutes + ":" + seconds + " " + timePeriod;
                    });
                });
            });
        });
    };

    this.setTime = function (time) {
        return self.getDateTime().then(function (datetime) {
            return self.getTime().then(function (currentTime) {
                var updatedDateTime = datetime.replace(currentTime, "time").replace('time', time);
                return self.setDateTime(updatedDateTime).then(function () {
                    return true;
                });
            });
        });
    };

    this.getDay = function () {
        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var dayElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//div[@class='datepicker-days']//td[contains(@class,'day active')]"));
            promiseUtil.getPresentElement(dayElementLocator).then(function (dayElement) {
                dayElement.getAttribute('innerHTML').then(function (day) {
                    deferred.fulfill(day);
                });
            });
        });

        return deferred.promise;
    };

    this.setDay = function (day) {
        return self.getYear().then(function (year) {
            return self.getMonth().then(function (month) {
                var updatedDate = month + "/" + day + "/" + year;
                return self.setDate(updatedDate).then(function (updatedDate) {
                    return true;
                });
            });
        });
    };

    this.getMonth = function () {

        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var monthElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//div[@class='datepicker-months']//span[contains(@class,'month active')]"));
            promiseUtil.getPresentElement(monthElementLocator).then(function (monthElement) {
                monthElement.getAttribute('innerHTML').then(function (month) {
                    deferred.fulfill(calenderMonths[month]);
                });
            });
        });

        return deferred.promise;
    };

    this.setMonth = function (month) {
        return self.getYear().then(function (year) {
            return self.getDay().then(function (day) {
                var updatedDate = month + "/" + day + "/" + year;
                return self.setDate(updatedDate).then(function (updatedDate) {
                    return true;
                });
            });
        });
    };

    this.getYear = function () {

        var deferred = protractor.promise.defer();

        self.isOpen().then(function (isOpened) {
            if (!isOpened)
                self.open();
            var yearElementLocator = element(by.xpath("//div[contains(@class,'picker-open')]//div[@class='datepicker-years']//span[contains(@class,'year active')]"));
            promiseUtil.getPresentElement(yearElementLocator).then(function (yearElement) {
                yearElement.getAttribute('innerHTML').then(function (year) {
                    deferred.fulfill(year);
                });
            });
        });

        return deferred.promise;
    };

    this.setYear = function (year) {
        return self.getMonth().then(function (month) {
            return self.getDay().then(function (day) {
                var updatedDate = month + "/" + day + "/" + year;
                return self.setDate(updatedDate).then(function (updatedDate) {
                    return true;
                });
            });
        });
    };

    this.getDate = function () {
        return self.getMonth().then(function (month) {
            return self.getYear().then(function (year) {
                return self.getDay().then(function (day) {
                    return month + "/" + day + "/" + year;
                });

            });
        });
    };

    this.setDate = function (date) {
        return self.getDateTime().then(function (datetime) {
            return self.getDate().then(function (currentDate) {
                var updatedDateTime = datetime.replace(currentDate, "date").replace('date', date);
                return self.setDateTime(updatedDateTime).then(function () {
                    return true;
                });
            });
        });
    };

    this.getDateTime = function () {
        var deferred = protractor.promise.defer();

        self.getDate().then(function (date) {
            promiseUtil.getPresentElement(self.dateTimePicker).then(function (picker) {
                picker.getAttribute('format').then(function (dateFormat) {
                    if (dateFormat.indexOf('h:mm:ss') >= 0) {
                        self.getTime().then(function (time) {
                            deferred.fulfill(date + " " + time);
                        });
                    }
                    else {
                        deferred.fulfill(date);
                    }
                });
            });
        });

        return deferred.promise;
    };

    this.setDateTime = function (dateTime) {
        var deferred = protractor.promise.defer();

        self.clear().then(function () {
            promiseUtil.getPresentElement(self.dateTimePicker).then(function (picker) {
                promiseUtil.sendKeys(picker.element(by.xpath("..")).element(by.tagName("input")),dateTime).then(function () {
                    browser.actions().sendKeys(protractor.Key.TAB).perform();
                    deferred.fulfill(true);
                });
            });
        });

        return deferred.promise;
    };
}
module.exports = DateTimePicker;

