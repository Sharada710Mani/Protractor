/**
 * Created by nekumar on 8/21/2017.
 */

// Not required now.

//var objManager = require("../PageObjects/ObjectManager.js");
//var objectObjManager = new objManager();
//
//
//var cem = objectObjManager.getGlobalElementManager("","");
//
//var loginM = function () {
//    var currentPage = 'loginMeridium';
//    browser.ignoreSynchronization=true;
//    this.loginWithAdminRights = function () {
//        console.log("Login to Meridium Utility!!");
//         browser.get(browser.params.login.meridiumURL).then(function () {
//            cem.findElement(currentPage, "userName").sendKeys("bl").then(function () {
//                cem.findElement(currentPage, "password").sendKeys("bl").then(function () {
//                    browser.driver.findElement(by.xpath("//select//option[text()='"
//                        + browser.params.login.meridiumDataBase + "']")).click().then(function () {
//                        cem.findElement(currentPage, "loginButton").click().then(function(){
//                            console.log("Login button cliked!!!");
//                        });
//                    })
//                })
//            })
//        },function(error){
//             console.log(error);
//         });
//
//        console.log("Before the method");
//
//       // return cem.findElement(currentPage, 'downArrow').click();
//    };
//
//}
//
//module.exports = loginM;

