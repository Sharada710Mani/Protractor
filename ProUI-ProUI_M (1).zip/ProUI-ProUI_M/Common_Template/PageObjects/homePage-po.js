/**
 * Created by nekumar on 8/14/2017.
 */
// (function () {
'use strict';
var currentPage = 'homePage';
var homePage = function () {
    // return {
        this.gSrchFindRecord= function (recordValue) {
            console.log("Click on Global Search button and seatch for record: " + recordValue);
            return cem.findElement(currentPage, "globalSearchIcon").click()
                .then(function () {
                    cem.findElement(currentPage, "globalSearchIcon").sendKeys(recordValue)
                        .then(function () {
                            cem.findElement(currentPage, "searchButton").click();
                        })
                });
        },

        this.gSrchFindRecordandClickFirst= function (recordValue) {
            this.gSrchFindRecord(recordValue).then(function(){

            });


        }

    // }
};

// function clickMainMenu(strMainMenu) {
//     return cem.findElement(currentPage, strMainMenu).click();
// }


module.exports = new homePage();
//}());



